<?php

namespace App\Controllers;

use App\Models\TH20_A_M;
use CodeIgniter\Controller;

class TH20_A_C extends Controller
{
    public function index()
    {
        // Load model
        $model = new TH20_A_M();

        // Mendapatkan total nilai dari field u13 dan u15
        $totals = $model->getTotals();

        // Mendapatkan count dari field u13 dan u15
        $counts = $model->getCounts();

        // Menghitung rumus (total_u13 + total_u15) / (count_u13 + count_u15)
        $total_u13 = $totals->total_u13;
        $total_u15 = $totals->total_u15;
        $count_u13 = $counts->count_u13;
        $count_u15 = $counts->count_u15;

        // Menghindari pembagian dengan nol
        $count_sum = $count_u13 + $count_u15;
        if ($count_sum == 0) {
            $average = null; // Atau Anda bisa mengembalikan nilai default seperti 0
        } else {
            $average = round(($total_u13 + $total_u15) / $count_sum);
        }

        // Passing data total ke view
        $data['total_u13'] = $totals->total_u13;
        $data['total_u15'] = $totals->total_u15;
        $data['count_u13'] = $counts->count_u13;
        $data['count_u15'] = $counts->count_u15;

        // Tambahkan rata-rata ke data yang akan dikirim ke view
        $data['average'] = $average;

        // Mendapatkan persentase dari jumlah entri untuk kolom u13 dan u15
        $percentages = $model->calculatePercentages();

        // Menyimpan persentase ke dalam data untuk dikirim ke view
        $data['percentage_u13'] = $percentages['percentage_u13'];
        $data['percentage_u15'] = $percentages['percentage_u15'];

        // Mendapatkan jumlah dari nilai yang sama di kolom 'p27'
        $sums = $model->KeselarasanVertikal();

        // Menyimpan sums ke dalam data untuk dikirim ke view
        $data['sums'] = $sums;

        // Mendapatkan jumlah dari nilai yang sama di kolom 'p27'
        $sums2 = $model->KeselarasanHorizontal();

        // Menyimpan sums ke dalam data untuk dikirim ke view
        $data['sums2'] = $sums2;

        $sums3 = $model->TingkatTempatBekerja();

        // Menyimpan sums ke dalam data untuk dikirim ke view
        $data['sums3'] = $sums3;

        // Mengalikan setiap nilai p18 dengan 1.2
        $multiplied_data = $model->pendapatan();

        // Debugging variabel $multiplied_data
        // echo '<pre>';
        // print_r($multiplied_data);
        // echo '</pre>';

        // Menambahkan hasil perkalian ke dalam data
        $data['multiplied_data'] = $multiplied_data;

        $result = $model->Pendapatan();

        // Passing data ke view
        $data['result_data'] = $result['result_data'];
        $data['big_ump_count_6_bulan'] = $result['big_ump_count_6_bulan'];
        $data['small_ump_count_6_bulan'] = $result['small_ump_count_6_bulan'];
        $data['big_ump_count_more_6_bulan'] = $result['big_ump_count_more_6_bulan'];
        $data['small_ump_count_more_6_bulan'] = $result['small_ump_count_more_6_bulan'];



        // Mendapatkan jumlah dari nilai yang sama di kolom '9'
        $sums4 = $model->Status();
        // Menyimpan sums ke dalam data untuk dikirim ke view
        $data['sums4'] = $sums4;

        // CONTROLLER UNTUK DATA YG BEKERJA
        $bekerja = $model->bekerja();

        $result = $model->bekerja();

        // Passing data ke view
        $data['result_data'] = $result['result_data'];
        $data['big_ump_count_6_bulan'] = $result['big_ump_count_6_bulan'];
        $data['small_ump_count_6_bulan'] = $result['small_ump_count_6_bulan'];
        $data['big_ump_count_more_6_bulan'] = $result['big_ump_count_more_6_bulan'];
        $data['small_ump_count_more_6_bulan'] = $result['small_ump_count_more_6_bulan'];
        // END CONTROLLER BEKERJA



        // CONTROLLER WIRASWASTA
        $bekerja = $model->wiraswasta();

        $result = $model->wiraswasta();

        // Passing data ke view
        $data['processed_data'] = $result['processed_data'];
        $data['count_large_ump_less_6_months'] = $result['count_large_ump_less_6_months'];
        $data['count_small_ump_less_6_months'] = $result['count_small_ump_less_6_months'];
        $data['count_large_ump_more_6_months'] = $result['count_large_ump_more_6_months'];
        $data['count_small_ump_more_6_months'] = $result['count_small_ump_more_6_months'];
        // END WIRASWASTA


        // Load view dengan data
        return view('th20_a', $data);
    }
}
