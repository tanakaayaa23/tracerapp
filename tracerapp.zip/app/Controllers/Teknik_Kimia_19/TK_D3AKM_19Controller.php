<?php

namespace App\Controllers\Teknik_Kimia_19;

use App\Controllers\BaseController;
use App\Models\Teknik_Kimia_19\TK_D3AKM_19;

class TK_D3AKM_19Controller extends BaseController
{
    public function index()
    {   
        // Instance dari model
        $model = new TK_D3AKM_19();

        // Memanggil method waktuTunggu dari model
        $data['waktuTunggu'] = $model->waktuTunggu();

        // Mendapatkan jumlah dari nilai yang sama di kolom 'p27'
        $sums = $model->KeselarasanVertikal();
        
        // Menyimpan sums ke dalam data untuk dikirim ke view
        $data['sums'] = $sums;

        // Mendapatkan jumlah dari nilai yang sama di kolom 'p27'
        $sums2 = $model->KeselarasanHorizontal();

        // Menyimpan sums ke dalam data untuk dikirim ke view
        $data['sums2'] = $sums2;

        $sums3 = $model->TingkatTempatBekerja();

        // Menyimpan sums ke dalam data untuk dikirim ke view
        $data['sums3'] = $sums3;
        //  // Memanggil method getAllRowsDIII dari model
        // $data['rowsDIII'] = $model->getAllRowsDIII();

            // CONTROLLER UNTUK DATA YG BEKERJA
        $bekerja = $model->bekerja();

        $result = $model->bekerja();
    
            // Passing data ke view
        $data['result_data'] = $result['result_data'];
        $data['big_ump_count_6_bulan'] = $result['big_ump_count_6_bulan'];
        $data['small_ump_count_6_bulan'] = $result['small_ump_count_6_bulan'];
        $data['big_ump_count_more_6_bulan'] = $result['big_ump_count_more_6_bulan'];
        $data['small_ump_count_more_6_bulan'] = $result['small_ump_count_more_6_bulan'];
        // END CONTROLLER BEKERJA


        // CONTROLLER WIRASWASTA
        $bekerja = $model->wiraswasta();    
        $result = $model->wiraswasta();

          // Passing data ke view
        $data['processed_data'] = $result['processed_data'];
        $data['count_large_ump_less_6_months'] = $result['count_large_ump_less_6_months'];
        $data['count_small_ump_less_6_months'] = $result['count_small_ump_less_6_months'];
        $data['count_large_ump_more_6_months'] = $result['count_large_ump_more_6_months'];
        $data['count_small_ump_more_6_months'] = $result['count_small_ump_more_6_months'];
        // END WIRASWASTA

        // Mendapatkan jumlah dari nilai yang sama di kolom '9'
        $sums4 = $model->Status();
        // Menyimpan sums ke dalam data untuk dikirim ke view
        $data['sums4'] = $sums4;

        $data['p16Values'] = $model->tesquery();
        // Debugging untuk melihat hasil
        // echo '<pre>';
        // print_r($data['p16Values']);
        // echo '</pre>';

        // Memuat view dengan data yang diperlukan
        return view('Teknik_Kimia_19/19-tk-d3akm', $data);
    }
}
