<?php

namespace App\Controllers;

use App\Models\TH19_M;
use CodeIgniter\Controller;

class TH19_C extends Controller
{
    public function index()
    {
        // Load model
        $model = new TH19_M();

        // Mendapatkan total nilai dari field t15 dan t17
        $totals = $model->getTotals();

        // Mendapatkan count dari field t15 dan t17
        $counts = $model->getCounts();

        // Menghitung rumus (total_t15 + total_t17) / (count_t15 + count_t17)
        $total_t15 = $totals->total_t15;
        $total_t17 = $totals->total_t17;
        $count_t15 = $counts->count_t15;
        $count_t17 = $counts->count_t17;

        // Menghindari pembagian dengan nol
        $count_sum = $count_t15 + $count_t17;
        if ($count_sum == 0) {
            $average = null; // Atau Anda bisa mengembalikan nilai default seperti 0
        } else {
            $average = round(($total_t15 + $total_t17) / $count_sum);
        }

        // Passing data total ke view
        $data['total_t15'] = $totals->total_t15;
        $data['total_t17'] = $totals->total_t17;
        $data['count_t15'] = $counts->count_t15;
        $data['count_t17'] = $counts->count_t17;

        // Tambahkan rata-rata ke data yang akan dikirim ke view
        $data['average'] = $average;

        // Mendapatkan persentase dari jumlah entri untuk kolom t15 dan t17
        $percentages = $model->calculatePercentages();

        // Menyimpan persentase ke dalam data untuk dikirim ke view
        $data['percentage_t15'] = $percentages['percentage_t15'];
        $data['percentage_t17'] = $percentages['percentage_t17'];

        // Mendapatkan jumlah dari nilai yang sama di kolom 'p27'
        $sums = $model->KeselarasanVertikal();

        // Menyimpan sums ke dalam data untuk dikirim ke view
        $data['sums'] = $sums;

        // Mendapatkan jumlah dari nilai yang sama di kolom 'p27'
        $sums2 = $model->KeselarasanHorizontal();

        // Menyimpan sums ke dalam data untuk dikirim ke view
        $data['sums2'] = $sums2;

        $sums3 = $model->TingkatTempatBekerja();

        // Menyimpan sums ke dalam data untuk dikirim ke view
        $data['sums3'] = $sums3;

        // Mengalikan setiap nilai p18 dengan 1.2
        $multiplied_data = $model->pendapatan();

        // Debugging variabel $multiplied_data
        // echo '<pre>';
        // print_r($multiplied_data);
        // echo '</pre>';

        // Menambahkan hasil perkalian ke dalam data
        $data['multiplied_data'] = $multiplied_data;

        $result = $model->Pendapatan();

        // Passing data ke view
        $data['result_data'] = $result['result_data'];
        $data['big_ump_count_6_bulan'] = $result['big_ump_count_6_bulan'];
        $data['small_ump_count_6_bulan'] = $result['small_ump_count_6_bulan'];
        $data['big_ump_count_more_6_bulan'] = $result['big_ump_count_more_6_bulan'];
        $data['small_ump_count_more_6_bulan'] = $result['small_ump_count_more_6_bulan'];



        // Mendapatkan jumlah dari nilai yang sama di kolom '9'
        $sums4 = $model->Status();
        // Menyimpan sums ke dalam data untuk dikirim ke view
        $data['sums4'] = $sums4;

        // CONTROLLER UNTUK DATA YG BEKERJA
        $bekerja = $model->bekerja();

        $result = $model->bekerja();

        // Passing data ke view
        $data['result_data'] = $result['result_data'];
        $data['big_ump_count_6_bulan'] = $result['big_ump_count_6_bulan'];
        $data['small_ump_count_6_bulan'] = $result['small_ump_count_6_bulan'];
        $data['big_ump_count_more_6_bulan'] = $result['big_ump_count_more_6_bulan'];
        $data['small_ump_count_more_6_bulan'] = $result['small_ump_count_more_6_bulan'];
        // END CONTROLLER BEKERJA



        // CONTROLLER WIRASWASTA
        $bekerja = $model->wiraswasta();

        $result = $model->wiraswasta();

        // Passing data ke view
        $data['processed_data'] = $result['processed_data'];
        $data['count_large_ump_less_6_months'] = $result['count_large_ump_less_6_months'];
        $data['count_small_ump_less_6_months'] = $result['count_small_ump_less_6_months'];
        $data['count_large_ump_more_6_months'] = $result['count_large_ump_more_6_months'];
        $data['count_small_ump_more_6_months'] = $result['count_small_ump_more_6_months'];
        // END WIRASWASTA


        // Load view dengan data
        return view('th19', $data);
    }
}
