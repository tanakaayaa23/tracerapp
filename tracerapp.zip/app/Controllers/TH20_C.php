<?php

namespace App\Controllers;

use App\Models\TH20_M;
use CodeIgniter\Controller;

class TH20_C extends Controller
{
    public function index()
    {
        // Load model
        $model = new TH20_M();

        // Mendapatkan total nilai dari field q13 dan q15
        $totals = $model->getTotals();

        // Mendapatkan count dari field q13 dan q15
        $counts = $model->getCounts();

        // Menghitung rumus (total_q13 + total_q15) / (count_q13 + count_q15)
        $total_q13 = $totals->total_q13;
        $total_q15 = $totals->total_q15;
        $count_q13 = $counts->count_q13;
        $count_q15 = $counts->count_q15;

        // Menghindari pembagian dengan nol
        $count_sum = $count_q13 + $count_q15;
        if ($count_sum == 0) {
            $average = null; // Atau Anda bisa mengembalikan nilai default seperti 0
        } else {
            $average = round(($total_q13 + $total_q15) / $count_sum);
        }

        // Passing data total ke view
        $data['total_q13'] = $totals->total_q13;
        $data['total_q15'] = $totals->total_q15;
        $data['count_q13'] = $counts->count_q13;
        $data['count_q15'] = $counts->count_q15;

        // Tambahkan rata-rata ke data yang akan dikirim ke view
        $data['average'] = $average;

        // Mendapatkan persentase dari jumlah entri untuk kolom q13 dan q15
        $percentages = $model->calculatePercentages();

        // Menyimpan persentase ke dalam data untuk dikirim ke view
        $data['percentage_q13'] = $percentages['percentage_q13'];
        $data['percentage_q15'] = $percentages['percentage_q15'];

        // Mendapatkan jumlah dari nilai yang sama di kolom 'p27'
        $sums = $model->KeselarasanVertikal();

        // Menyimpan sums ke dalam data untuk dikirim ke view
        $data['sums'] = $sums;

        // Mendapatkan jumlah dari nilai yang sama di kolom 'p27'
        $sums2 = $model->KeselarasanHorizontal();

        // Menyimpan sums ke dalam data untuk dikirim ke view
        $data['sums2'] = $sums2;

        $sums3 = $model->TingkatTempatBekerja();

        // Menyimpan sums ke dalam data untuk dikirim ke view
        $data['sums3'] = $sums3;

        // CONTROLLER BEKERJA
        $bekerja = $model->bekerja();

        $result = $model->bekerja();

        // Passing data ke view
        $data['result_data'] = $result['result_data'];
        $data['big_ump_count_6_bulan'] = $result['big_ump_count_6_bulan'];
        $data['small_ump_count_6_bulan'] = $result['small_ump_count_6_bulan'];
        $data['big_ump_count_more_6_bulan'] = $result['big_ump_count_more_6_bulan'];
        $data['small_ump_count_more_6_bulan'] = $result['small_ump_count_more_6_bulan'];
        // END CONTROLLER BEKERJA



        // CONTROLLER WIRASWASTA
        $bekerja = $model->wiraswasta();

        $result = $model->wiraswasta();

        // Passing data ke view
        $data['processed_data'] = $result['processed_data'];
        $data['count_large_ump_less_6_months'] = $result['count_large_ump_less_6_months'];
        $data['count_small_ump_less_6_months'] = $result['count_small_ump_less_6_months'];
        $data['count_large_ump_more_6_months'] = $result['count_large_ump_more_6_months'];
        $data['count_small_ump_more_6_months'] = $result['count_small_ump_more_6_months'];
        // END WIRASWASTA
        // Mendapatkan jumlah dari nilai yang sama di kolom '9'
        $sums5 = $model->Status();
        // Menyimpan sums ke dalam data untuk dikirim ke view
        $data['sums5'] = $sums5;



        // Load view dengan data
        return view('th20', $data);
    }
}
