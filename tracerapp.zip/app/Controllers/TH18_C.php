<?php

namespace App\Controllers;

use App\Models\TH18_M;
use CodeIgniter\Controller;

class TH18_C extends Controller
{
    public function index()
    {
        // Load model
        $model = new TH18_M();

        // Mendapatkan total nilai dari field r5 dan r7
        $totals = $model->getTotals();

        // Mendapatkan count dari field r5 dan r7
        $counts = $model->getCounts();

        // Menghitung rumus (total_r5 + total_r7) / (count_r5 + count_r7)
        $total_r5 = $totals->total_r5;
        $total_r7 = $totals->total_r7;
        $count_r5 = $counts->count_r5;
        $count_r7 = $counts->count_r7;

        // Menghindari pembagian dengan nol
        $count_sum = $count_r5 + $count_r7;
        if ($count_sum == 0) {
            $average = null; // Atau Anda bisa mengembalikan nilai default seperti 0
        } else {
            $average = round(($total_r5 + $total_r7) / $count_sum);
        }

        // Passing data total ke view
        $data['total_r5'] = $totals->total_r5;
        $data['total_r7'] = $totals->total_r7;
        $data['count_r5'] = $counts->count_r5;
        $data['count_r7'] = $counts->count_r7;

        // Tambahkan rata-rata ke data yang akan dikirim ke view
        $data['average'] = $average;

        // Mendapatkan persentase dari jumlah entri untuk kolom r5 dan r7
        $percentages = $model->calculatePercentages();

        // Menyimpan persentase ke dalam data untuk dikirim ke view
        $data['percentage_r5'] = $percentages['percentage_r5'];
        $data['percentage_r7'] = $percentages['percentage_r7'];

        // Mendapatkan jumlah dari nilai yang sama di kolom 'p27'
        $sums = $model->KeselarasanVertikal();

        // Menyimpan sums ke dalam data untuk dikirim ke view
        $data['sums'] = $sums;

        // Mendapatkan jumlah dari nilai yang sama di kolom 'p27'
        $sums2 = $model->KeselarasanHorizontal();

        // Menyimpan sums ke dalam data untuk dikirim ke view
        $data['sums2'] = $sums2;

        $sums3 = $model->TingkatTempatBekerja();

        // Menyimpan sums ke dalam data untuk dikirim ke view
        $data['sums3'] = $sums3;

        // Mendapatkan jumlah dari nilai yang sama di kolom '9'
        $sums4 = $model->Status();
        // Menyimpan sums ke dalam data untuk dikirim ke view
        $data['sums4'] = $sums4;

        // CONTROLLER UNTUK DATA YG BEKERJA
        $bekerja = $model->bekerja();

        $result = $model->bekerja();

        // Passing data ke view
        $data['result_data'] = $result['result_data'];
        $data['big_ump_count_6_bulan'] = $result['big_ump_count_6_bulan'];
        $data['small_ump_count_6_bulan'] = $result['small_ump_count_6_bulan'];
        $data['big_ump_count_more_6_bulan'] = $result['big_ump_count_more_6_bulan'];
        $data['small_ump_count_more_6_bulan'] = $result['small_ump_count_more_6_bulan'];
        // END CONTROLLER BEKERJA



        // CONTROLLER WIRASWASTA
        $bekerja = $model->wiraswasta();

        $result = $model->wiraswasta();

        // Passing data ke view
        $data['processed_data'] = $result['processed_data'];
        $data['count_large_ump_less_6_months'] = $result['count_large_ump_less_6_months'];
        $data['count_small_ump_less_6_months'] = $result['count_small_ump_less_6_months'];
        $data['count_large_ump_more_6_months'] = $result['count_large_ump_more_6_months'];
        $data['count_small_ump_more_6_months'] = $result['count_small_ump_more_6_months'];
        // END WIRASWASTA


        // Load view dengan data
        return view('th18', $data);
    }
}
