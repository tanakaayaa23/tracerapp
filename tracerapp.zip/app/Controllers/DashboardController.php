<?php

namespace App\Controllers;

use App\Models\DashboardModel;
use CodeIgniter\Controller;

class DashboardController extends Controller
{
    public function index()
    {
        // Load model
        $model = new DashboardModel();

        // Mendapatkan total nilai dari field p15 dan p16
        $totals = $model->getTotals();

        // Mendapatkan count dari field p15 dan p16
        $counts = $model->getCounts();

        // Menghitung rumus (total_p15 + total_p16) / (count_p15 + count_p16)
        $total_p15 = $totals->total_p15;
        $total_p16 = $totals->total_p16;
        $count_p15 = $counts->count_p15;
        $count_p16 = $counts->count_p16;

        // Menghindari pembagian dengan nol
        $count_sum = $count_p15 + $count_p16;
        if ($count_sum == 0) {
            $average = null; // Atau Anda bisa mengembalikan nilai default seperti 0
        } else {
            $average = round(($total_p15 + $total_p16) / $count_sum);
        }

        // Passing data total ke view
        $data['total_p15'] = $totals->total_p15;
        $data['total_p16'] = $totals->total_p16;
        $data['count_p15'] = $counts->count_p15;
        $data['count_p16'] = $counts->count_p16;

        // Tambahkan rata-rata ke data yang akan dikirim ke view
        $data['average'] = $average;

        // Mendapatkan persentase dari jumlah entri untuk kolom p15 dan p16
        $percentages = $model->calculatePercentages();

        // Menyimpan persentase ke dalam data untuk dikirim ke view
        $data['percentage_p15'] = $percentages['percentage_p15'];
        $data['percentage_p16'] = $percentages['percentage_p16'];

        // Mendapatkan jumlah dari nilai yang sama di kolom 'p27'
        $sums = $model->KeselarasanVertikal();

        // Menyimpan sums ke dalam data untuk dikirim ke view
        $data['sums'] = $sums;

        // Mendapatkan jumlah dari nilai yang sama di kolom 'p27'
        $sums2 = $model->KeselarasanHorizontal();

        // Menyimpan sums ke dalam data untuk dikirim ke view
        $data['sums2'] = $sums2;

        $sums3 = $model->TingkatTempatBekerja();

        // Menyimpan sums ke dalam data untuk dikirim ke view
        $data['sums3'] = $sums3;

        // Mengalikan setiap nilai p18 dengan 1.2
        $multiplied_data = $model->pendapatan();

        // Debugging variabel $multiplied_data
        // echo '<pre>';
        // print_r($multiplied_data);
        // echo '</pre>';

        // Menambahkan hasil perkalian ke dalam data
        $data['multiplied_data'] = $multiplied_data;

        $result = $model->Pendapatan();

        // Passing data ke view
        $data['result_data'] = $result['result_data'];
        $data['big_ump_count_6_bulan'] = $result['big_ump_count_6_bulan'];
        $data['small_ump_count_6_bulan'] = $result['small_ump_count_6_bulan'];
        $data['big_ump_count_more_6_bulan'] = $result['big_ump_count_more_6_bulan'];
        $data['small_ump_count_more_6_bulan'] = $result['small_ump_count_more_6_bulan'];



        // Mendapatkan jumlah dari nilai yang sama di kolom '9'
        $sums4 = $model->Status();
        // Menyimpan sums ke dalam data untuk dikirim ke view
        $data['sums4'] = $sums4;

        // CONTROLLER UNTUK DATA YG BEKERJA
        $bekerja = $model->bekerja();

        $result = $model->bekerja();

        // Passing data ke view
        $data['result_data'] = $result['result_data'];
        $data['big_ump_count_6_bulan'] = $result['big_ump_count_6_bulan'];
        $data['small_ump_count_6_bulan'] = $result['small_ump_count_6_bulan'];
        $data['big_ump_count_more_6_bulan'] = $result['big_ump_count_more_6_bulan'];
        $data['small_ump_count_more_6_bulan'] = $result['small_ump_count_more_6_bulan'];
        // END CONTROLLER BEKERJA



        // CONTROLLER WIRASWASTA
        $bekerja = $model->wiraswasta();

        $result = $model->wiraswasta();

        // Passing data ke view
        $data['processed_data'] = $result['processed_data'];
        $data['count_large_ump_less_6_months'] = $result['count_large_ump_less_6_months'];
        $data['count_small_ump_less_6_months'] = $result['count_small_ump_less_6_months'];
        $data['count_large_ump_more_6_months'] = $result['count_large_ump_more_6_months'];
        $data['count_small_ump_more_6_months'] = $result['count_small_ump_more_6_months'];
        // END WIRASWASTA


        // Load view dengan data
        return view('dashboard', $data);
    }
}
