<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

$routes->get('/', 'DashboardController::index');
$routes->get('th19', 'TH19_C::index');
$routes->get('th18', 'TH18_C::index');
$routes->get('th20', 'TH20_C::index');
$routes->get('th20_A', 'TH20_A_C::index');
$routes->get('th21', 'TH21_C::index');


// Prodi 2022
// Teknik Sipil
$routes->get('prodi', 'Teknik_Sipil\ProdiController::index');
$routes->get('22-ts-d3tkg', 'Teknik_Sipil\TS_D3TKG_22Controller::index');
$routes->get('22-ts-d4tpj', 'Teknik_Sipil\TS_D4TPJ_22Controller::index');
$routes->get('22-ts-d4tpg', 'Teknik_Sipil\TS_D4TPG_22Controller::index');
$routes->get('22-ts-s2ri', 'Teknik_Sipil\TS_S2RI_22Controller::index');

// Teknik Mesin
$routes->get('22-tm-d3tae', 'Teknik_Mesin\TM_D3TAE_22Controller::index');
$routes->get('22-tm-d3tm', 'Teknik_Mesin\TM_D3TM_22Controller::index');
$routes->get('22-tm-d4pm', 'Teknik_Mesin\TM_D4PM_22Controller::index');
$routes->get('22-tm-d4tkm', 'Teknik_Mesin\TM_D4TKM_22Controller::index');

// Teknik Refigerasi Tata Udara
$routes->get('22-tu-d3tptu', 'Teknik_Refrigerasi_Tata_Udara\TU_D3TPTU_22Controller::index');
$routes->get('22-tu-d4tptu', 'Teknik_Refrigerasi_Tata_Udara\TU_D4TPTU_22Controller::index');

// Teknik Konversi Energi
$routes->get('22-tke-d3tke', 'Teknik_Konversi_Energi\TKE_D3TKE_22Controller::index');
$routes->get('22-tke-d4tke', 'Teknik_Konversi_Energi\TKE_D4TKE_22Controller::index');
$routes->get('22-tke-d4tpl', 'Teknik_Konversi_Energi\TKE_D4TPL_22Controller::index');

// Teknik Elektro
$routes->get('22-te-d3tek', 'Teknik_Elektro\TE_D3TEK_22Controller::index');
$routes->get('22-te-d3tlk', 'Teknik_Elektro\TE_D3TLK_22Controller::index');
$routes->get('22-te-d3ttk', 'Teknik_Elektro\TE_D3TTK_22Controller::index');
$routes->get('22-te-d4tek', 'Teknik_Elektro\TE_D4TEK_22Controller::index');
$routes->get('22-te-d4toi', 'Teknik_Elektro\TE_D4TOI_22Controller::index');
$routes->get('22-te-d4ttk', 'Teknik_Elektro\TE_D4TTK_22Controller::index');

// Teknik Kimia
$routes->get('22-tk-d3akm', 'Teknik_Kimia\TK_D3AKM_22Controller::index');
$routes->get('22-tk-d3tkm', 'Teknik_Kimia\TK_D3TKM_22Controller::index');
$routes->get('22-tk-d4tkpb', 'Teknik_Kimia\TK_D4TKPB_22Controller::index');

// Teknik Komputer Informatika
$routes->get('22-tki-d3ti', 'Teknik_Komputer_Informatika\TKI_D3TI_22Controller::index');
$routes->get('22-tki-d4ti', 'Teknik_Komputer_Informatika\TKI_D4TI_22Controller::index');

// Akuntansi
$routes->get('22-ak-d3ak', 'Akuntansi\AK_D3AK_22Controller::index');
$routes->get('22-ak-d3kb', 'Akuntansi\AK_D3KB_22Controller::index');
$routes->get('22-ak-d4ak', 'Akuntansi\AK_D4AK_22Controller::index');
$routes->get('22-ak-d4ap', 'Akuntansi\AK_D4AP_22Controller::index');
$routes->get('22-ak-d4ks', 'Akuntansi\AK_D4KS_22Controller::index');
$routes->get('22-ak-s2kps', 'Akuntansi\AK_S2KPS_22Controller::index');

// Administrasi Niaga
$routes->get('22-an-d3ab', 'Administrasi_Niaga\AN_D3AB_22Controller::index');
$routes->get('22-an-d3mp', 'Administrasi_Niaga\AN_D3MP_22Controller::index');
$routes->get('22-an-d3upw', 'Administrasi_Niaga\AN_D3UPW_22Controller::index');
$routes->get('22-an-d4ab', 'Administrasi_Niaga\AN_D4AB_22Controller::index');
$routes->get('22-an-d4ma', 'Administrasi_Niaga\AN_D4MA_22Controller::index');
$routes->get('22-an-d4mp', 'Administrasi_Niaga\AN_D4MP_22Controller::index');

// Bahasa Inggris
$routes->get('22-bi-d3bi', 'Inggris\BI_D3BI_22Controller::index');
// End Prodi 2022




// Prodi 2021
// Teknik Sipil 21
$routes->get('21-ts-d3tkg', 'Teknik_Sipil_21\TS_D3TKG_21Controller::index');
$routes->get('21-ts-d3tks', 'Teknik_Sipil_21\TS_D3TKS_21Controller::index');
$routes->get('21-ts-d4tpj', 'Teknik_Sipil_21\TS_D4TPJ_21Controller::index');
$routes->get('21-ts-d4tpg', 'Teknik_Sipil_21\TS_D4TPG_21Controller::index');
$routes->get('21-ts-s2ri', 'Teknik_Sipil_21\TS_S2RI_21Controller::index');

// Teknik Mesin 21
$routes->get('21-tm-d3tae', 'Teknik_Mesin_21\TM_D3TAE_21Controller::index');
$routes->get('21-tm-d3tm', 'Teknik_Mesin_21\TM_D3TM_21Controller::index');
$routes->get('21-tm-d4pm', 'Teknik_Mesin_21\TM_D4PM_21Controller::index');
$routes->get('21-tm-d4tkm', 'Teknik_Mesin_21\TM_D4TKM_21Controller::index');

// Teknik Refigerasi Tata Udara 21
$routes->get('21-tu-d3tptu', 'Teknik_Refrigerasi_Tata_Udara_21\TU_D3TPTU_21Controller::index');
$routes->get('21-tu-d4tptu', 'Teknik_Refrigerasi_Tata_Udara_21\TU_D4TPTU_21Controller::index');

// Teknik Konversi Energi 21
$routes->get('21-tke-d3tke', 'Teknik_Konversi_Energi_21\TKE_D3TKE_21Controller::index');
$routes->get('21-tke-d4tke', 'Teknik_Konversi_Energi_21\TKE_D4TKE_21Controller::index');
$routes->get('21-tke-d3tpl', 'Teknik_Konversi_Energi_21\TKE_D3TPL_21Controller::index');

// Teknik Konversi Energi 21
$routes->get('21-te-d3te', 'Teknik_Elektro_21\TE_D3TE_21Controller::index');
$routes->get('21-te-d4te', 'Teknik_Elektro_21\TE_D4TE_21Controller::index');
$routes->get('21-te-d3tl', 'Teknik_Elektro_21\TE_D3TL_21Controller::index');
$routes->get('21-te-d4toi', 'Teknik_Elektro_21\TE_D4TOI_21Controller::index');
$routes->get('21-te-d3tt', 'Teknik_Elektro_21\TE_D3TT_21Controller::index');
$routes->get('21-te-d4tt', 'Teknik_Elektro_21\TE_D4TT_21Controller::index');

// Teknik Kimia 21
$routes->get('21-tk-d3tk', 'Teknik_Kimia_21\TK_D3TK_21Controller::index');
$routes->get('21-tk-d3ak', 'Teknik_kimia_21\TK_D3AK_21Controller::index');
$routes->get('21-tk-d4tkpb', 'Teknik_Kimia_21\TK_D4TKPB_21Controller::index');

// Teknik Informatika 21
$routes->get('21-tki-d3ti', 'Teknik_Informatika_21\TKI_D3TI_21Controller::index');
$routes->get('21-tki-d4ti', 'Teknik_Informatika_21\TKI_D4TI_21Controller::index');

// Akuntansi 21
$routes->get('21-ak-d3ak', 'Akuntansi_21\AK_D3AK_21Controller::index');
$routes->get('21-ak-d3kdp', 'Akuntansi_21\AK_D3KDP_21Controller::index');
$routes->get('21-ak-d4amp', 'Akuntansi_21\AK_D4AMP_21Controller::index');
$routes->get('21-ak-d4ak', 'Akuntansi_21\AK_D4AK_21Controller::index');
$routes->get('21-ak-d4ks', 'Akuntansi_21\AK_D4KS_21Controller::index');

// Administrasi niaga 21
$routes->get('21-an-d3ab', 'Administrasi_Niaga_21\AN_D3AB_21Controller::index');
$routes->get('21-an-d3mp', 'Administrasi_Niaga_21\AN_D3MP_21Controller::index');
$routes->get('21-an-d3upw', 'Administrasi_Niaga_21\AN_D3UPW_21Controller::index');
$routes->get('21-an-d4ab', 'Administrasi_Niaga_21\AN_D4AB_21Controller::index');
$routes->get('21-an-d4ma', 'Administrasi_Niaga_21\AN_D4MA_21Controller::index');
$routes->get('21-an-d4mp', 'Administrasi_Niaga_21\AN_D4MP_21Controller::index');

// Bahasa Inggris 21
$routes->get('21-bi-d3bi', 'Bahasa_Inggris_21\BI_D3BI_21Controller::index');
// End Prodi 2021




// Prodi 2020A
// Inggris_20A
$routes->get('20a-bi-d3bi', 'Inggris_20A\BI_D3BI_20AController::index');

// Aministrasi_Niaga_20A
// Administrasi Niaga
$routes->get('20a-an-d3ab', 'Administrasi_Niaga_20A\AN_D3AB_20AController::index');
$routes->get('20a-an-d3mp', 'Administrasi_Niaga_20A\AN_D3MP_20AController::index');
$routes->get('20a-an-d3upw', 'Administrasi_Niaga_20A\AN_D3UPW_20AController::index');
$routes->get('20a-an-d4ab', 'Administrasi_Niaga_20A\AN_D4AB_20AController::index');
$routes->get('20a-an-d4ma', 'Administrasi_Niaga_20A\AN_D4MA_20AController::index');
$routes->get('20a-an-d4mp', 'Administrasi_Niaga_20A\AN_D4MP_20AController::index');

// Teknik_Komputer_Informatika_20A
$routes->get('20a-tki-d3ti', 'Teknik_Komputer_Informatika_20A\TKI_D3TI_20AController::index');
$routes->get('20a-tki-d4ti', 'Teknik_Komputer_Informatika_20A\TKI_D4TI_20AController::index');

// Teknik_Refigerasi_Tata_Udara_20A
$routes->get('20a-tu-d3tptu', 'Teknik_Refrigerasi_Tata_Udara_20A\TU_D3TPTU_20AController::index');
$routes->get('20a-tu-d4tptu', 'Teknik_Refrigerasi_Tata_Udara_20A\TU_D4TPTU_20AController::index');

// Akuntansi_20A
$routes->get('20a-ak-d3ak', 'Akuntansi_20A\AK_D3AK_20AController::index');
$routes->get('20a-ak-d3kb', 'Akuntansi_20A\AK_D3KB_20AController::index');
$routes->get('20a-ak-d4ak', 'Akuntansi_20A\AK_D4AK_20AController::index');
$routes->get('20a-ak-d4ap', 'Akuntansi_20A\AK_D4AP_20AController::index');
$routes->get('20a-ak-d4ks', 'Akuntansi_20A\AK_D4KS_20AController::index');

// Teknik_Elektro_20A
$routes->get('20a-te-d3tek', 'Teknik_Elektro_20A\TE_D3TEK_20AController::index');
$routes->get('20a-te-d3tlk', 'Teknik_Elektro_20A\TE_D3TLK_20AController::index');
$routes->get('20a-te-d3ttk', 'Teknik_Elektro_20A\TE_D3TTK_20AController::index');
$routes->get('20a-te-d4tek', 'Teknik_Elektro_20A\TE_D4TEK_20AController::index');
$routes->get('20a-te-d4toi', 'Teknik_Elektro_20A\TE_D4TOI_20AController::index');
$routes->get('20a-te-d4ttk', 'Teknik_Elektro_20A\TE_D4TTK_20AController::index');

// Teknik_Konversi_Energi_20A
$routes->get('20a-tke-d3tke', 'Teknik_Konversi_Energi_20A\TKE_D3TKE_20AController::index');
$routes->get('20a-tke-d4tke', 'Teknik_Konversi_Energi_20A\TKE_D4TKE_20AController::index');
$routes->get('20a-tke-d4tpl', 'Teknik_Konversi_Energi_20A\TKE_D4TPL_20AController::index');

// Teknik_Kimia_20A
$routes->get('20a-tk-d3akm', 'Teknik_Kimia_20A\TK_D3AKM_20AController::index');
$routes->get('20a-tk-d3tkm', 'Teknik_Kimia_20A\TK_D3TKM_20AController::index');
$routes->get('20a-tk-d4tkpb', 'Teknik_Kimia_20A\TK_D4TKPB_20AController::index');

// Teknik_Mesin_20A
$routes->get('20a-tm-d3tae', 'Teknik_Mesin_20A\TM_D3TAE_20AController::index');
$routes->get('20a-tm-d3tm', 'Teknik_Mesin_20A\TM_D3TM_20AController::index');
$routes->get('20a-tm-d4pm', 'Teknik_Mesin_20A\TM_D4PM_20AController::index');
$routes->get('20a-tm-d4tkm', 'Teknik_Mesin_20A\TM_D4TKM_20AController::index');

// Teknik_Sipil_20A
$routes->get('20a-ts-d3tks', 'Teknik_Sipil_20A\TS_D3TKS_20AController::index');
$routes->get('20a-ts-d3tkg', 'Teknik_Sipil_20A\TS_D3TKG_20AController::index');
$routes->get('20a-ts-d4tpg', 'Teknik_Sipil_20A\TS_D4TPG_20AController::index');
$routes->get('20a-ts-d4tpj', 'Teknik_Sipil_20A\TS_D4TPJ_20AController::index');
// End Prodi 2020A



// Prodi 2019
// Inggris_19
$routes->get('19-bi-d3bi', 'Inggris_19\BI_D3BI_19Controller::index');

// Administrasi_Niaga_19
$routes->get('19-an-d3ab', 'Administrasi_Niaga_19\AN_D3AB_19Controller::index');
$routes->get('19-an-d3mp', 'Administrasi_Niaga_19\AN_D3MP_19Controller::index');
$routes->get('19-an-d3upw', 'Administrasi_Niaga_19\AN_D3UPW_19Controller::index');
$routes->get('19-an-d4ab', 'Administrasi_Niaga_19\AN_D4AB_19Controller::index');
$routes->get('19-an-d4ma', 'Administrasi_Niaga_19\AN_D4MA_19Controller::index');
$routes->get('19-an-d4mp', 'Administrasi_Niaga_19\AN_D4MP_19Controller::index');

// Akuntansi_19
$routes->get('19-ak-d3ak', 'Akuntansi_19\AK_D3AK_19Controller::index');
$routes->get('19-ak-d3kb', 'Akuntansi_19\AK_D3kb_19Controller::index');
$routes->get('19-ak-d4ak', 'Akuntansi_19\AK_D4AK_19Controller::index');
$routes->get('19-ak-d4ap', 'Akuntansi_19\AK_D4AP_19Controller::index');
$routes->get('19-ak-d4ks', 'Akuntansi_19\AK_D4KS_19Controller::index');

// Teknik_Elektro_19
$routes->get('19-te-d3tek', 'Teknik_Elektro_19\TE_D3TEK_19Controller::index');
$routes->get('19-te-d3tlk', 'Teknik_Elektro_19\TE_D3TLK_19Controller::index');
$routes->get('19-te-d3ttk', 'Teknik_Elektro_19\TE_D3TTK_19Controller::index');
$routes->get('19-te-d4tek', 'Teknik_Elektro_19\TE_D4TEK_19Controller::index');
$routes->get('19-te-d4toi', 'Teknik_Elektro_19\TE_D4TOI_19Controller::index');
$routes->get('19-te-d4ttk', 'Teknik_Elektro_19\TE_D4TTK_19Controller::index');

// Teknik_Kimia_19
$routes->get('19-tk-d3akm', 'Teknik_Kimia_19\TK_D3AKM_19Controller::index');
$routes->get('19-tk-d3tkm', 'Teknik_Kimia_19\TK_D3TKM_19Controller::index');
$routes->get('19-tk-d4tkpb', 'Teknik_Kimia_19\TK_D4TKPB_19Controller::index');

// Teknik_Komputer_Informatika_19
$routes->get('19-tki-d3ti', 'Teknik_Komputer_Informatika_19\TKI_D3TI_19Controller::index');
$routes->get('19-tki-d4ti', 'Teknik_Komputer_Informatika_19\TKI_D4TI_19Controller::index');

// Teknik_Konversi_Energi_19
$routes->get('19-tke-d3tke', 'Teknik_Konversi_Energi_19\TKE_D3TKE_19Controller::index');
$routes->get('19-tke-d4tke', 'Teknik_Konversi_Energi_19\TKE_D4TKE_19Controller::index');
$routes->get('19-tke-d3tpl', 'Teknik_Konversi_Energi_19\TKE_D3TPL_19Controller::index');

// Teknik_Mesin_19
$routes->get('19-tm-d3tae', 'Teknik_Mesin_19\TM_D3TAE_19Controller::index');
$routes->get('19-tm-d3tm', 'Teknik_Mesin_19\TM_D3TM_19Controller::index');
$routes->get('19-tm-d4pm', 'Teknik_Mesin_19\TM_D4PM_19Controller::index');
$routes->get('19-tm-d4tkm', 'Teknik_Mesin_19\TM_D4TKM_19Controller::index');

// Teknik_Refrigerasi_Tata_Udara_19
$routes->get('19-tu-d3tptu', 'Teknik_Refrigerasi_Tata_Udara_19\TU_D3TPTU_19Controller::index');
$routes->get('19-tu-d4tptu', 'Teknik_Refrigerasi_Tata_Udara_19\TU_D4TPTU_19Controller::index');

// Teknik_Sipil_19
$routes->get('19-ts-d3tks', 'Teknik_Sipil_19\TS_D3TKS_19Controller::index');
$routes->get('19-ts-d3tkg', 'Teknik_Sipil_19\TS_D3TKG_19Controller::index');
$routes->get('19-ts-d4tpg', 'Teknik_Sipil_19\TS_D4TPG_19Controller::index');
$routes->get('19-ts-d4tpj', 'Teknik_Sipil_19\TS_D4TPJ_19Controller::index');
// End Prodi 2019



// Prodi 2020
// Teknik Sipil 20
$routes->get('20-ts-d3tkg', 'Teknik_Sipil_20\TS_D3TKG_20Controller::index');
$routes->get('20-ts-d3tks', 'Teknik_Sipil_20\TS_D3TKS_20Controller::index');
$routes->get('20-ts-d4tpj', 'Teknik_Sipil_20\TS_D4TPJ_20Controller::index');
$routes->get('20-ts-d4tpg', 'Teknik_Sipil_20\TS_D4TPG_20Controller::index');

// Teknik Mesin 20
$routes->get('20-tm-d3tae', 'Teknik_Mesin_20\TM_D3TAE_20Controller::index');
$routes->get('20-tm-d3tm', 'Teknik_Mesin_20\TM_D3TM_20Controller::index');
$routes->get('20-tm-d4pm', 'Teknik_Mesin_20\TM_D4PM_20Controller::index');
$routes->get('20-tm-d4tkm', 'Teknik_Mesin_20\TM_D4TKM_20Controller::index');

// Teknik Refigerasi Tata Udara 20
$routes->get('20-tu-d3tptu', 'Teknik_Refrigerasi_Tata_Udara_20\TU_D3TPTU_20Controller::index');
$routes->get('20-tu-d4tptu', 'Teknik_Refrigerasi_Tata_Udara_20\TU_D4TPTU_20Controller::index');

// Teknik Konversi Energi 20
$routes->get('20-tke-d3tke', 'Teknik_Konversi_Energi_20\TKE_D3TKE_20Controller::index');
$routes->get('20-tke-d4tke', 'Teknik_Konversi_Energi_20\TKE_D4TKE_20Controller::index');
$routes->get('20-tke-d3tpl', 'Teknik_Konversi_Energi_20\TKE_D3TPL_20Controller::index');

// Teknik Konversi Energi 20
$routes->get('20-te-d3te', 'Teknik_Elektro_20\TE_D3TE_20Controller::index');
$routes->get('20-te-d4te', 'Teknik_Elektro_20\TE_D4TE_20Controller::index');
$routes->get('20-te-d3tl', 'Teknik_Elektro_20\TE_D3TL_20Controller::index');
$routes->get('20-te-d4toi', 'Teknik_Elektro_20\TE_D4TOI_20Controller::index');
$routes->get('20-te-d3tt', 'Teknik_Elektro_20\TE_D3TT_20Controller::index');
$routes->get('20-te-d4tt', 'Teknik_Elektro_20\TE_D4TT_20Controller::index');

// Teknik Kimia 20
$routes->get('20-tk-d3tk', 'Teknik_Kimia_20\TK_D3TK_20Controller::index');
$routes->get('20-tk-d3ak', 'Teknik_kimia_20\TK_D3AK_20Controller::index');
$routes->get('20-tk-d4tkpb', 'Teknik_Kimia_20\TK_D4TKPB_20Controller::index');

// Teknik Informatika 20
$routes->get('20-tki-d3ti', 'Teknik_Informatika_20\TKI_D3TI_20Controller::index');
$routes->get('20-tki-d4ti', 'Teknik_Informatika_20\TKI_D4TI_20Controller::index');

// Akuntansi 20
$routes->get('20-ak-d3ak', 'Akuntansi_20\AK_D3AK_20Controller::index');
$routes->get('20-ak-d3kdp', 'Akuntansi_20\AK_D3KDP_20Controller::index');
$routes->get('20-ak-d4amp', 'Akuntansi_20\AK_D4AMP_20Controller::index');
$routes->get('20-ak-d4ak', 'Akuntansi_20\AK_D4AK_20Controller::index');
$routes->get('20-ak-d4ks', 'Akuntansi_20\AK_D4KS_20Controller::index');

// Administrasi niaga 20
$routes->get('20-an-d3ab', 'Administrasi_Niaga_20\AN_D3AB_20Controller::index');
$routes->get('20-an-d3mp', 'Administrasi_Niaga_20\AN_D3MP_20Controller::index');
$routes->get('20-an-d3upw', 'Administrasi_Niaga_20\AN_D3UPW_20Controller::index');
$routes->get('20-an-d4ab', 'Administrasi_Niaga_20\AN_D4AB_20Controller::index');
$routes->get('20-an-d4ma', 'Administrasi_Niaga_20\AN_D4MA_20Controller::index');
$routes->get('20-an-d4mp', 'Administrasi_Niaga_20\AN_D4MP_20Controller::index');

// Bahasa Inggris 20
$routes->get('20-bi-d3bi', 'Bahasa_Inggris_20\BI_D3BI_20Controller::index');
// End Prodi 2020



// Prodi 2018
// Inggris_18
$routes->get('18-bi-d3bi', 'Inggris_18\BI_D3BI_18Controller::index');

// Administrasi_Niaga_18
$routes->get('18-an-d3ab', 'Administrasi_Niaga_18\AN_D3AB_18Controller::index');
$routes->get('18-an-d3mp', 'Administrasi_Niaga_18\AN_D3MP_18Controller::index');
$routes->get('18-an-d3upw', 'Administrasi_Niaga_18\AN_D3UPW_18Controller::index');
$routes->get('18-an-d4ab', 'Administrasi_Niaga_18\AN_D4AB_18Controller::index');
$routes->get('18-an-d4ma', 'Administrasi_Niaga_18\AN_D4MA_18Controller::index');
$routes->get('18-an-d4mp', 'Administrasi_Niaga_18\AN_D4MP_18Controller::index');

// Akuntansi_18
$routes->get('18-ak-d3ak', 'Akuntansi_18\AK_D3AK_18Controller::index');
$routes->get('18-ak-d3kb', 'Akuntansi_18\AK_D3KB_18Controller::index');
$routes->get('18-ak-d4ak', 'Akuntansi_18\AK_D4AK_18Controller::index');
$routes->get('18-ak-d4ap', 'Akuntansi_18\AK_D4AP_18Controller::index');
$routes->get('18-ak-d4ks', 'Akuntansi_18\AK_D4KS_18Controller::index');

// Teknik_Elektro_18
$routes->get('18-te-d3tek', 'Teknik_Elektro_18\TE_D3TEK_18Controller::index');
$routes->get('18-te-d3tlk', 'Teknik_Elektro_18\TE_D3TLK_18Controller::index');
$routes->get('18-te-d3ttk', 'Teknik_Elektro_18\TE_D3TTK_18Controller::index');
$routes->get('18-te-d4tek', 'Teknik_Elektro_18\TE_D4TEK_18Controller::index');
$routes->get('18-te-d4toi', 'Teknik_Elektro_18\TE_D4TOI_18Controller::index');
$routes->get('18-te-d4ttk', 'Teknik_Elektro_18\TE_D4TTK_18Controller::index');

// Teknik_Komputer_Informatika_18
$routes->get('18-tki-d3ti', 'Teknik_Komputer_Informatika_18\TKI_D3TI_18Controller::index');
$routes->get('18-tki-d4ti', 'Teknik_Komputer_Informatika_18\TKI_D4TI_18Controller::index');

// Teknik_Kimia 18
$routes->get('18-tk-d3akm', 'Teknik_Kimia_18\TK_D3AKM_18Controller::index');
$routes->get('18-tk-d3tkm', 'Teknik_Kimia_18\TK_D3TKM_18Controller::index');
$routes->get('18-tk-d4tkpb', 'Teknik_Kimia_18\TK_D4TKPB_18Controller::index');

// Teknik_Konversi_Energi 18
$routes->get('18-tke-d3tke', 'Teknik_Konversi_Energi_18\TKE_D3TKE_18Controller::index');
$routes->get('18-tke-d4tke', 'Teknik_Konversi_Energi_18\TKE_D4TKE_18Controller::index');
$routes->get('18-tke-d4tpl', 'Teknik_Konversi_Energi_18\TKE_D4TPL_18Controller::index');

// Bahasa Inggris 18
$routes->get('18-bi-d3bi', 'Bahasa_Inggris_18\BI_D3BI_18Controller::index');

// Teknik Mesin 18
$routes->get('18-tm-d3tae', 'Teknik_Mesin_18\TM_D3TAE_18Controller::index');
$routes->get('18-tm-d3tm', 'Teknik_Mesin_18\TM_D3TM_18Controller::index');
$routes->get('18-tm-d4pm', 'Teknik_Mesin_18\TM_D4PM_18Controller::index');
$routes->get('18-tm-d4tkm', 'Teknik_Mesin_18\TM_D4TKM_18Controller::index');

// Teknik Refigerasi Tata Udara 18
$routes->get('18-tu-d3tptu', 'Teknik_Refrigerasi_Tata_Udara_18\TU_D3TPTU_18Controller::index');
$routes->get('18-tu-d4tptu', 'Teknik_Refrigerasi_Tata_Udara_18\TU_D4TPTU_18Controller::index');

// Teknik Sipil 18
$routes->get('18-ts-d3tkg', 'Teknik_Sipil_18\TS_D3TKG_18Controller::index');
$routes->get('18-ts-d3tks', 'Teknik_Sipil_18\TS_D3TKS_18Controller::index');
$routes->get('18-ts-d4tpj', 'Teknik_Sipil_18\TS_D4TPJ_18Controller::index');
$routes->get('18-ts-d4tpg', 'Teknik_Sipil_18\TS_D4TPG_18Controller::index');
