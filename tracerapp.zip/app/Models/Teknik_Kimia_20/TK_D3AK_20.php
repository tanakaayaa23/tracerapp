<?php

namespace App\Models\Teknik_Kimia_20;

use CodeIgniter\Model;

class TK_D3AK_20 extends Model
{
    protected $table = '21_for_20';

    protected function getProgramStudiQuery()
    {
        return $this->where('program_studi', 'DIII - Analis Kimia');
    }

    public function waktuTunggu()
    {
        $query = $this->getProgramStudiQuery();

        // Menghitung total nilai untuk kolom q13 dan q15
        $totalsQuery = $query->select('SUM(q13) AS total_q13, SUM(q15) AS total_q15')->get();
        $totals = $totalsQuery->getRow();

        // Menghitung jumlah (count) nilai untuk kolom q13 dan q15
        $countsQuery = $this->getProgramStudiQuery()->select('COUNT(q13) AS count_q13, COUNT(q15) AS count_q15')->get();
        $counts = $countsQuery->getRow();

        // Menghindari pembagian dengan nol
        $countSum = $counts->count_q13 + $counts->count_q15;
        if ($countSum == 0) {
            $average = null; // Atau Anda bisa mengembalikan nilai default seperti 0
        } else {
            // Menghitung rata-rata
            $average = round(($totals->total_q13 + $totals->total_q15) / $countSum);
        }

        // Menghitung persentase
        $total = $counts->count_q13 + $counts->count_q15;
        if ($total == 0) {
            $percentage_q13 = 0;
            $percentage_q15 = 0;
        } else {
            $percentage_q13 = ($counts->count_q13 / $total) * 100;
            $percentage_q15 = ($counts->count_q15 / $total) * 100;
        }

        return [
            'average' => $average,
            'percentage_q13' => $percentage_q13,
            'percentage_q15' => $percentage_q15,
        ];
    }

    // Keselarasan Vertikal
    public function KeselarasanVertikal()
    {
        $query = $this->getProgramStudiQuery();

        // Menggunakan fungsi agregasi SUM() untuk menjumlahkan data yang memiliki nilai yang sama di kolom 'q23' dengan filter program_studi
        $query = $query->select('q23, COUNT(q23) as total')
            ->groupBy('q23')
            ->get();

        // Mengonversi hasil query menjadi array
        $results = $query->getResultArray();

        // Menginisialisasi array untuk menyimpan hasil penjumlahan
        $sums = [];

        // Iterasi melalui hasil query dan menyimpan hasil penjumlahan ke dalam array
        foreach ($results as $result) {
            $sums[$result['q23']] = $result['total'];
        }

        return $sums;
    }

    // Keselarasan Horizontal
    public function KeselarasanHorizontal()
    {
        $query = $this->getProgramStudiQuery();

        // Menggunakan fungsi agregasi SUM() untuk menjumlahkan data yang memiliki nilai yang sama di kolom 'q22' dengan filter program_studi
        $query = $query->select('q22, COUNT(q22) as total')
            ->groupBy('q22')
            ->get();

        // Mengonversi hasil query menjadi array
        $results = $query->getResultArray();

        // Menginisialisasi array untuk menyimpan hasil penjumlahan
        $sums2 = [];

        // Iterasi melalui hasil query dan menyimpan hasil penjumlahan ke dalam array
        foreach ($results as $result) {
            $sums2[$result['q22']] = $result['total'];
        }

        return $sums2;
    }

    public function TingkatTempatBekerja()
    {
        $query = $this->getProgramStudiQuery();

        // Menghitung total data
        $totalQuery = $query->select('COUNT(q17) as total')->get();
        $totalResult = $totalQuery->getRowArray();
        $total = $totalResult['total'];

        // Menggunakan fungsi agregasi COUNT() untuk menghitung jumlah data untuk setiap nilai di kolom 'q17' dengan filter program_studi
        $query = $this->getProgramStudiQuery()->select('q17, COUNT(q17) as count')
            ->groupBy('q17')
            ->get();

        // Mengonversi hasil query menjadi array
        $results = $query->getResultArray();

        // Menginisialisasi array untuk menyimpan hasil persentase
        $percentages = [];

        // Iterasi melalui hasil query dan menghitung persentase untuk setiap nilai
        foreach ($results as $result) {
            $percentage = ($result['count'] / $total) * 100;
            $percentages[$result['q17']] = $percentage;
        }

        return $percentages;
    }

    public function bekerja()
    {
        $query = $this->getProgramStudiQuery();

        // Ambil data dari tabel 23_for_22 untuk 'Rekayasa Infrastruktur' saja
        $query = $query->select('q14, q16, q12, q8')->get();

        // Mengambil hasil query dalam bentuk array
        $results = $query->getResultArray();

        // Menginisialisasi variabel untuk menyimpan jumlah nilai besar dan kecil ump berdasarkan durasi pekerjaan
        $big_ump_count_6_bulan = 0;
        $small_ump_count_6_bulan = 0;
        $big_ump_count_more_6_bulan = 0;
        $small_ump_count_more_6_bulan = 0;

        // Inisialisasi array untuk menyimpan hasil
        $result_data = [];

        // Iterasi melalui hasil query
        foreach ($results as $row) {
            // Mendapatkan nilai q14
            $q14 = $row['q14'];
            // Mendapatkan nilaiq16
            $q16 = $row['q16'];
            // Mendapatkan nilai q12
            $q12 = $row['q12'];
            // Mendapatkan nilai q8
            $q8 = $row['q8'];

            // Skip if q8 is not 1
            if ($q8 != 1) {
                continue;
            }

            // Mendapatkan nilai ump dari kode provinsi yang sesuai denganq16
            $ump_query = $this->db->table('ump_20')
                ->select('ump')
                ->where('kode_provinsi', $q16)
                ->get();
            $ump_row = $ump_query->getRow();

            // Mengalikan nilai ump dengan 1.2
            $multiplied_ump = $ump_row ? $ump_row->ump * 1.2 : null;

            // Membandingkan nilai q14 dengan nilai ump dikali 1.2
            if ($multiplied_ump !== null) {
                if ($q14 < $multiplied_ump) {
                    if ($q12 == 1) {
                        $small_ump_count_6_bulan++;
                    } elseif ($q12 == 2) {
                        $small_ump_count_more_6_bulan++;
                    }
                    $comparison_result = 'Kecil UMP';
                } elseif ($q14 > $multiplied_ump) {
                    if ($q12 == 1) {
                        $big_ump_count_6_bulan++;
                    } elseif ($q12 == 2) {
                        $big_ump_count_more_6_bulan++;
                    }
                    $comparison_result = 'Besar UMP';
                } else {
                    $comparison_result = 'Sama dengan UMP';
                }
            } else {
                // UMP tidak ditemukan
                $comparison_result = 'UMP tidak tersedia';
            }

            // Menentukan status berdasarkan nilai q12
            $employment_duration = '';
            if ($q12 == 1) {
                $employment_duration = 'Kurang dari 6 bulan';
            } elseif ($q12 == 2) {
                $employment_duration = 'Lebih dari 6 bulan';
            }

            // Tambahkan data ke dalam array hasil
            $result_data[] = [
                'q14' => $q14,
                'q16' => $q16,
                'multiplied_ump' => $multiplied_ump, // Tambahkan nilai ump yang telah dikali 1.2
                'comparison_result' => $comparison_result,
                'employment_duration' => $employment_duration,
                'q8' => $q8
            ];
        }

    //     // Debug output untuk memeriksa hasil akhir
    // echo '<pre>';
    // echo "Debugging output for result data:\n";
    // print_r($result_data);
    // echo "\n\n";
    // echo "Debugging output for UMP counts:\n";
    // echo "big_ump_count_6_bulan: $big_ump_count_6_bulan\n";
    // echo "small_ump_count_6_bulan: $small_ump_count_6_bulan\n";
    // echo "big_ump_count_more_6_bulan: $big_ump_count_more_6_bulan\n";
    // echo "small_ump_count_more_6_bulan: $small_ump_count_more_6_bulan\n";
    // echo '</pre>';

        // Return hasil dan jumlah nilai besar dan kecil ump
        return [
            'result_data' => $result_data,
            'big_ump_count_6_bulan' => $big_ump_count_6_bulan,
            'small_ump_count_6_bulan' => $small_ump_count_6_bulan,
            'big_ump_count_more_6_bulan' => $big_ump_count_more_6_bulan,
            'small_ump_count_more_6_bulan' => $small_ump_count_more_6_bulan
        ];
    }

    // PENDAPATAN YG WIRASWATA
    public function wiraswasta()
    {
        $query = $this->getProgramStudiQuery();

        // Ambil data dari tabel 23_for_22
        $query = $query->select('q14, q16, q12, q8')->get();

        // Mengambil hasil query dalam bentuk array
        $data_rows = $query->getResultArray();

        // Menginisialisasi variabel untuk menyimpan jumlah nilai besar dan kecil ump berdasarkan durasi pekerjaan
        $count_large_ump_less_6_months = 0;
        $count_small_ump_less_6_months = 0;
        $count_large_ump_more_6_months = 0;
        $count_small_ump_more_6_months = 0;

        // Inisialisasi array untuk menyimpan hasil
        $processed_data = [];

        // Iterasi melalui hasil query
        foreach ($data_rows as $data_row) {
            // Mendapatkan nilai q14
            $value_q14 = $data_row['q14'];
            // Mendapatkan nilaiq16
            $value_q16 = $data_row['q16'];
            // Mendapatkan nilai q12
            $value_q12 = $data_row['q12'];
            // Mendapatkan nilai q8
            $value_q8 = $data_row['q8'];

            // Skip if q8 is not 2
            if ($value_q8 != 2) {
                continue;
            }

            // Mendapatkan nilai ump dari kode provinsi yang sesuai denganq16
            $ump_query = $this->db->table('ump_20')
                ->select('ump')
                ->where('kode_provinsi', $value_q16)
                ->get();
            $ump_row = $ump_query->getRow();

            // Mengalikan nilai ump dengan 1.2
            $multiplied_ump_value = $ump_row ? $ump_row->ump * 1.2 : null;

            // Membandingkan nilai q14 dengan nilai ump dikali 1.2
            if ($multiplied_ump_value !== null) {
                if ($value_q14 < $multiplied_ump_value) {
                    if ($value_q12 == 1) {
                        $count_small_ump_less_6_months++;
                    } elseif ($value_q12 == 2) {
                        $count_small_ump_more_6_months++;
                    }
                    $comparison_result = 'Kecil UMP';
                } elseif ($value_q14 > $multiplied_ump_value) {
                    if ($value_q12 == 1) {
                        $count_large_ump_less_6_months++;
                    } elseif ($value_q12 == 2) {
                        $count_large_ump_more_6_months++;
                    }
                    $comparison_result = 'Besar UMP';
                } else {
                    $comparison_result = 'Sama dengan UMP';
                }
            } else {
                // UMP tidak ditemukan
                $comparison_result = 'UMP tidak tersedia';
            }

            // Menentukan status berdasarkan nilai q12
            $employment_duration = '';
            if ($value_q12 == 1) {
                $employment_duration = 'Kurang dari 6 bulan';
            } elseif ($value_q12 == 2) {
                $employment_duration = 'Lebih dari 6 bulan';
            }

            // Tambahkan data ke dalam array hasil
            $processed_data[] = [
                'q14' => $value_q14,
                'q16' => $value_q16,
                'multiplied_ump_value' => $multiplied_ump_value, // Tambahkan nilai ump yang telah dikali 1.2
                'comparison_result' => $comparison_result,
                'employment_duration' => $employment_duration,
                'q8' => $value_q8
            ];
        }

        // Return hasil dan jumlah nilai besar dan kecil ump
        return [
            'processed_data' => $processed_data,
            'count_large_ump_less_6_months' => $count_large_ump_less_6_months,
            'count_small_ump_less_6_months' => $count_small_ump_less_6_months,
            'count_large_ump_more_6_months' => $count_large_ump_more_6_months,
            'count_small_ump_more_6_months' => $count_small_ump_more_6_months
        ];
    }

    // END PENDAPATAN YG WIRASWASTA

    public function Status()
    {
        $query = $this->getProgramStudiQuery();

        // Menggunakan fungsi agregasi SUM() untuk menjumlahkan data yang memiliki nilai yang sama di kolom 'q8'
        $query = $query->select('q8, COUNT(q8) as total')
            ->groupBy('q8')
            ->get();

        // Mengonversi hasil query menjadi array
        $results_status = $query->getResultArray();

        // Menginisialisasi array untuk menyimpan hasil penjumlahan
        $sums = [];

        // Iterasi melalui hasil query dan menyimpan hasil penjumlahan ke dalam array
        foreach ($results_status as $result) {
            $sums[$result['q8']] = $result['total'];
        }

        return $sums;
    }

    public function tesquery()
    {
        // Mengambil semua nilai kolom 'q15' di mana nilai kolom 'program_studi' adalah 'Rekayasa Infrastruktur'
        return $this->select('q15')->where('program_studi', 'DIII - Analis Kimia')->findAll();
    }
}