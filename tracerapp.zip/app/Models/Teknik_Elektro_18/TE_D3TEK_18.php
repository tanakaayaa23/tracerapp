<?php

namespace App\Models\Teknik_Elektro_18;

use CodeIgniter\Model;

class TE_D3TEK_18 extends Model
{
    protected $table = '20_for_18';

    protected function getProgramStudiQuery()
    {
        return $this->where('program_studi', 'DIII - Teknik Elektronika');
    }

    public function waktuTunggu()
    {
        $query = $this->getProgramStudiQuery();

        // Menghitung total nilai untuk kolom r5 dan r7
        $totalsQuery = $query->select('SUM(r5) AS total_r5, SUM(r7) AS total_r7')->get();
        $totals = $totalsQuery->getRow();

        // Menghitung jumlah (count) nilai untuk kolom r5 dan r7
        $countsQuery = $this->getProgramStudiQuery()->select('COUNT(r5) AS count_r5, COUNT(r7) AS count_r7')->get();
        $counts = $countsQuery->getRow();

        // Menghindari pembagian dengan nol
        $countSum = $counts->count_r5 + $counts->count_r7;
        if ($countSum == 0) {
            $average = null; // Atau Anda bisa mengembalikan nilai default seperti 0
        } else {
            // Menghitung rata-rata
            $average = round(($totals->total_r5 + $totals->total_r7) / $countSum);
        }

        // Menghitung persentase
        $total = $counts->count_r5 + $counts->count_r7;
        if ($total == 0) {
            $percentage_r5 = 0;
            $percentage_r7 = 0;
        } else {
            $percentage_r5 = ($counts->count_r5 / $total) * 100;
            $percentage_r7 = ($counts->count_r7 / $total) * 100;
        }

        return [
            'average' => $average,
            'percentage_r5' => $percentage_r5,
            'percentage_r7' => $percentage_r7,
        ];
    }

    // Keselarasan Vertikal
    public function KeselarasanVertikal()
    {
        $query = $this->getProgramStudiQuery();

        // Menggunakan fungsi agregasi SUM() untuk menjumlahkan data yang memiliki nilai yang sama di kolom 'r22' dengan filter program_studi
        $query = $query->select('r22, COUNT(r22) as total')
            ->groupBy('r22')
            ->get();

        // Mengonversi hasil query menjadi array
        $results = $query->getResultArray();

        // Menginisialisasi array untuk menyimpan hasil penjumlahan
        $sums = [];

        // Iterasi melalui hasil query dan menyimpan hasil penjumlahan ke dalam array
        foreach ($results as $result) {
            $sums[$result['r22']] = $result['total'];
        }

        return $sums;
    }

    // Keselarasan Horizontal
    public function KeselarasanHorizontal()
    {
        $query = $this->getProgramStudiQuery();

        // Menggunakan fungsi agregasi SUM() untuk menjumlahkan data yang memiliki nilai yang sama di kolom 'r21' dengan filter program_studi
        $query = $query->select('r21, COUNT(r21) as total')
            ->groupBy('r21')
            ->get();

        // Mengonversi hasil query menjadi array
        $results = $query->getResultArray();

        // Menginisialisasi array untuk menyimpan hasil penjumlahan
        $sums2 = [];

        // Iterasi melalui hasil query dan menyimpan hasil penjumlahan ke dalam array
        foreach ($results as $result) {
            $sums2[$result['r21']] = $result['total'];
        }

        return $sums2;
    }

    public function TingkatTempatBekerja()
    {
        $query = $this->getProgramStudiQuery();

        // Menghitung total data
        $totalQuery = $query->select('COUNT(r18_a) as total')->get();
        $totalResult = $totalQuery->getRowArray();
        $total = $totalResult['total'];

        // Menggunakan fungsi agregasi COUNT() untuk menghitung jumlah data untuk setiap nilai di kolom 'r18_a' dengan filter program_studi
        $query = $this->getProgramStudiQuery()->select('r18_a, COUNT(r18_a) as count')
            ->groupBy('r18_a')
            ->get();

        // Mengonversi hasil query menjadi array
        $results = $query->getResultArray();

        // Menginisialisasi array untuk menyimpan hasil persentase
        $percentages = [];

        // Iterasi melalui hasil query dan menghitung persentase untuk setiap nilai
        foreach ($results as $result) {
            $percentage = ($result['count'] / $total) * 100;
            $percentages[$result['r18_a']] = $percentage;
        }

        return $percentages;
    }

    public function bekerja()
    {
        $query = $this->getProgramStudiQuery();

        // Ambil data dari tabel 23_for_22 untuk 'Rekayasa Infrastruktur' saja
        $query = $query->select('r20, r24, r7, r15')->get();

        // Mengambil hasil query dalam bentuk array
        $results = $query->getResultArray();

        // Menginisialisasi variabel untuk menyimpan jumlah nilai besar dan kecil ump berdasarkan durasi pekerjaan
        $big_ump_count_6_bulan = 0;
        $small_ump_count_6_bulan = 0;
        $big_ump_count_more_6_bulan = 0;
        $small_ump_count_more_6_bulan = 0;

        // Inisialisasi array untuk menyimpan hasil
        $result_data = [];

        // Iterasi melalui hasil query
        foreach ($results as $row) {
            // Mendapatkan nilai r20
            $r20 = $row['r20'];
            // Mendapatkan nilair24
            $r24 = $row['r24'];
            // Mendapatkan nilai r7
            $r7 = $row['r7'];
            // Mendapatkan nilai r15
            $r15 = $row['r15'];

            // Skip if r15 is not 1
            if ($r15 != 'Ya') {
                continue;
            }

            // Mendapatkan nilai ump dari kode provinsi yang sesuai denganr24
            $ump_query = $this->db->table('provinsi')
                ->select('ump_18')
                ->where('kode_provinsi', $r24)
                ->get();
            $ump_row = $ump_query->getRow();

            // Mengalikan nilai ump dengan 1.2
            $multiplied_ump = $ump_row ? $ump_row->ump_18 * 1.2 : null;

            // Membandingkan nilai r20 dengan nilai ump dikali 1.2
            if ($multiplied_ump !== null) {
                if ($r20 < $multiplied_ump) {
                    if ($r7 == 1) {
                        $small_ump_count_6_bulan++;
                    } elseif ($r7 == 2) {
                        $small_ump_count_more_6_bulan++;
                    }
                    $comparison_result = 'Kecil UMP';
                } elseif ($r20 > $multiplied_ump) {
                    if ($r7 == 1) {
                        $big_ump_count_6_bulan++;
                    } elseif ($r7 == 2) {
                        $big_ump_count_more_6_bulan++;
                    }
                    $comparison_result = 'Besar UMP';
                } else {
                    $comparison_result = 'Sama dengan UMP';
                }
            } else {
                // UMP tidak ditemukan
                $comparison_result = 'UMP tidak tersedia';
            }

            // Menentukan status berdasarkan nilai r7
            $employment_duration = '';
            if ($r7 == 1) {
                $employment_duration = 'Kurang dari 6 bulan';
            } elseif ($r7 == 2) {
                $employment_duration = 'Lebih dari 6 bulan';
            }

            // Tambahkan data ke dalam array hasil
            $result_data[] = [
                'r20' => $r20,
                'r24' => $r24,
                'multiplied_ump' => $multiplied_ump, // Tambahkan nilai ump yang telah dikali 1.2
                'comparison_result' => $comparison_result,
                'employment_duration' => $employment_duration,
                'r15' => $r15
            ];
        }

    //     // Debug output untuk memeriksa hasil akhir
    // echo '<pre>';
    // echo "Debugging output for result data:\n";
    // print_r($result_data);
    // echo "\n\n";
    // echo "Debugging output for UMP counts:\n";
    // echo "big_ump_count_6_bulan: $big_ump_count_6_bulan\n";
    // echo "small_ump_count_6_bulan: $small_ump_count_6_bulan\n";
    // echo "big_ump_count_more_6_bulan: $big_ump_count_more_6_bulan\n";
    // echo "small_ump_count_more_6_bulan: $small_ump_count_more_6_bulan\n";
    // echo '</pre>';

        // Return hasil dan jumlah nilai besar dan kecil ump
        return [
            'result_data' => $result_data,
            'big_ump_count_6_bulan' => $big_ump_count_6_bulan,
            'small_ump_count_6_bulan' => $small_ump_count_6_bulan,
            'big_ump_count_more_6_bulan' => $big_ump_count_more_6_bulan,
            'small_ump_count_more_6_bulan' => $small_ump_count_more_6_bulan
        ];
    }

    // PENDAPATAN YG WIRASWATA
    public function wiraswasta()
    {
        $query = $this->getProgramStudiQuery();

        // Ambil data dari tabel 23_for_22
        $query = $query->select('r20, r24, r7, r18')->get();

        // Mengambil hasil query dalam bentuk array
        $data_rows = $query->getResultArray();

        // Menginisialisasi variabel untuk menyimpan jumlah nilai besar dan kecil ump berdasarkan durasi pekerjaan
        $count_large_ump_less_6_months = 0;
        $count_small_ump_less_6_months = 0;
        $count_large_ump_more_6_months = 0;
        $count_small_ump_more_6_months = 0;

        // Inisialisasi array untuk menyimpan hasil
        $processed_data = [];

        // Iterasi melalui hasil query
        foreach ($data_rows as $data_row) {
            // Mendapatkan nilai r20
            $value_r20 = $data_row['r20'];
            // Mendapatkan nilair24
            $value_r24 = $data_row['r24'];
            // Mendapatkan nilai r7
            $value_r7 = $data_row['r7'];
            // Mendapatkan nilai r18
            $value_r18 = $data_row['r18'];

            // Skip if r18 is not 2
            if ($value_r18 != 'Wiraswasta/perusahaan sendiri') {
                continue;
            }

            // Mendapatkan nilai ump dari kode provinsi yang sesuai denganr24
            $ump_query = $this->db->table('provinsi')
                ->select('ump_18')
                ->where('kode_provinsi', $value_r24)
                ->get();
            $ump_row = $ump_query->getRow();

            // Mengalikan nilai ump dengan 1.2
            $multiplied_ump_value = $ump_row ? $ump_row->ump_18 * 1.2 : null;

            // Membandingkan nilai r20 dengan nilai ump dikali 1.2
            if ($multiplied_ump_value !== null) {
                if ($value_r20 < $multiplied_ump_value) {
                    if ($value_r7 == 1) {
                        $count_small_ump_less_6_months++;
                    } elseif ($value_r7 == 2) {
                        $count_small_ump_more_6_months++;
                    }
                    $comparison_result = 'Kecil UMP';
                } elseif ($value_r20 > $multiplied_ump_value) {
                    if ($value_r7 == 1) {
                        $count_large_ump_less_6_months++;
                    } elseif ($value_r7 == 2) {
                        $count_large_ump_more_6_months++;
                    }
                    $comparison_result = 'Besar UMP';
                } else {
                    $comparison_result = 'Sama dengan UMP';
                }
            } else {
                // UMP tidak ditemukan
                $comparison_result = 'UMP tidak tersedia';
            }

            // Menentukan status berdasarkan nilai r7
            $employment_duration = '';
            if ($value_r7 == 1) {
                $employment_duration = 'Kurang dari 6 bulan';
            } elseif ($value_r7 == 2) {
                $employment_duration = 'Lebih dari 6 bulan';
            }

            // Tambahkan data ke dalam array hasil
            $processed_data[] = [
                'r20' => $value_r20,
                'r24' => $value_r24,
                'multiplied_ump_value' => $multiplied_ump_value, // Tambahkan nilai ump yang telah dikali 1.2
                'comparison_result' => $comparison_result,
                'employment_duration' => $employment_duration,
                'r18' => $value_r18
            ];
        }

        // Return hasil dan jumlah nilai besar dan kecil ump
        return [
            'processed_data' => $processed_data,
            'count_large_ump_less_6_months' => $count_large_ump_less_6_months,
            'count_small_ump_less_6_months' => $count_small_ump_less_6_months,
            'count_large_ump_more_6_months' => $count_large_ump_more_6_months,
            'count_small_ump_more_6_months' => $count_small_ump_more_6_months
        ];
    }

    // END PENDAPATAN YG WIRASWASTA

    public function Status()
{
    $query = $this->getProgramStudiQuery(); // Get the initial query

    // Menghitung jumlah data yang memiliki nilai 'Ya' pada kolom 'r15'
    $query_r15 = $query->selectCount('r15', 'total_r15')
        ->where('program_studi', 'DIII - Teknik Elektronika') // Filter untuk program_studi
        ->where('r15', 'Ya') // Filter untuk field 'r15'
        ->get();

    // Menghitung jumlah data yang memiliki nilai 'Wiraswasta/perusahaan sendiri' pada kolom 'r18'
    $query_r18 = $query->selectCount('r18', 'total_r18')
        ->where('program_studi', 'DIII - Teknik Elektronika') // Filter untuk program_studi
        ->where('r18', 'Wiraswasta/perusahaan sendiri') // Filter untuk field 'r18'
        ->get();
        
    // Mengonversi hasil query menjadi array
    $result_r15 = $query_r15->getRowArray();
    $result_r18 = $query_r18->getRowArray();
    
    // Menginisialisasi array untuk menyimpan hasil penjumlahan
    $sums = [
        'r15' => $result_r15['total_r15'],
        'r18' => $result_r18['total_r18']
    ];
    
    return $sums;
}



    public function tesquery()
    {
        // Mengambil semua nilai kolom 'r7' di mana nilai kolom 'program_studi' adalah 'Rekayasa Infrastruktur'
        return $this->select('r7')->where('program_studi', 'DIII - Teknik Elektronika')->findAll();
    }
}