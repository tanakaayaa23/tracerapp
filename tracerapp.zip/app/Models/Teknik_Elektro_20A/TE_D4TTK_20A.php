<?php

namespace App\Models\Teknik_Elektro_20A;

use CodeIgniter\Model;

class TE_D4TTK_20A extends Model
{
    protected $table = '21_for_20_a';

    // Metode pembantu untuk filter program_studi
    protected function getProgramStudiQuery()
    {
        return $this->where('program_studi', 'DIV - Teknik Telekomunikasi');
    }

    public function waktuTunggu()
    {
        $query = $this->getProgramStudiQuery();

        // Menghitung total nilai untuk kolom u13 dan u15
        $totalsQuery = $query->select('SUM(u13) AS total_u13, SUM(u15) AS total_u15')->get();
        $totals = $totalsQuery->getRow();

        // Menghitung jumlah (count) nilai untuk kolom u13 dan u15
        $countsQuery = $this->getProgramStudiQuery()->select('COUNT(u13) AS count_u13, COUNT(u15) AS count_u15')->get();
        $counts = $countsQuery->getRow();

        // Menghindari pembagian dengan nol
        $countSum = $counts->count_u13 + $counts->count_u15;
        if ($countSum == 0) {
            $average = null; // Atau Anda bisa mengembalikan nilai default seperti 0
        } else {
            // Menghitung rata-rata
            $average = round(($totals->total_u13 + $totals->total_u15) / $countSum);
        }

        // Menghitung persentase
        $total = $counts->count_u13 + $counts->count_u15;
        if ($total == 0) {
            $percentage_u13 = 0;
            $percentage_u15 = 0;
        } else {
            $percentage_u13 = ($counts->count_u13 / $total) * 100;
            $percentage_u15 = ($counts->count_u15 / $total) * 100;
        }

        return [
            'average' => $average,
            'percentage_u13' => $percentage_u13,
            'percentage_u15' => $percentage_u15,
        ];
    }

    // Keselarasan Vertikal
    public function KeselarasanVertikal()
    {
        $query = $this->getProgramStudiQuery();

        // Menggunakan fungsi agregasi SUM() untuk menjumlahkan data yang memiliki nilai yang sama di kolom 'u24' dengan filter program_studi
        $query = $query->select('u24, COUNT(u24) as total')
            ->groupBy('u24')
            ->get();

        // Mengonversi hasil query menjadi array
        $results = $query->getResultArray();

        // Menginisialisasi array untuk menyimpan hasil penjumlahan
        $sums = [];

        // Iterasi melalui hasil query dan menyimpan hasil penjumlahan ke dalam array
        foreach ($results as $result) {
            $sums[$result['u24']] = $result['total'];
        }

        return $sums;
    }

    // Keselarasan Horizontal
    public function KeselarasanHorizontal()
    {
        $query = $this->getProgramStudiQuery();

        // Menggunakan fungsi agregasi SUM() untuk menjumlahkan data yang memiliki nilai yang sama di kolom 'u23' dengan filter program_studi
        $query = $query->select('u23, COUNT(u23) as total')
            ->groupBy('u23')
            ->get();

        // Mengonversi hasil query menjadi array
        $results = $query->getResultArray();

        // Menginisialisasi array untuk menyimpan hasil penjumlahan
        $sums2 = [];

        // Iterasi melalui hasil query dan menyimpan hasil penjumlahan ke dalam array
        foreach ($results as $result) {
            $sums2[$result['u23']] = $result['total'];
        }

        return $sums2;
    }

    public function TingkatTempatBekerja()
    {
        $query = $this->getProgramStudiQuery();

        // Menghitung total data
        $totalQuery = $query->select('COUNT(u18) as total')->get();
        $totalResult = $totalQuery->getRowArray();
        $total = $totalResult['total'];

        // Menggunakan fungsi agregasi COUNT() untuk menghitung jumlah data untuk setiap nilai di kolom 'u18' dengan filter program_studi
        $query = $this->getProgramStudiQuery()->select('u18, COUNT(u18) as count')
            ->groupBy('u18')
            ->get();

        // Mengonversi hasil query menjadi array
        $results = $query->getResultArray();

        // Menginisialisasi array untuk menyimpan hasil persentase
        $percentages = [];

        // Iterasi melalui hasil query dan menghitung persentase untuk setiap nilai
        foreach ($results as $result) {
            $percentage = ($result['count'] / $total) * 100;
            $percentages[$result['u18']] = $percentage;
        }

        return $percentages;
    }

    public function bekerja()
    {
        $query = $this->getProgramStudiQuery();

        // Ambil data dari tabel 23_for_22 untuk 'DIV - Teknik Telekomunikasi' saja
        $query = $query->select('u14, u16, u12, u7_1')->get();

        // Mengambil hasil query dalam bentuk array
        $results = $query->getResultArray();

        // Menginisialisasi variabel untuk menyimpan jumlah nilai besar dan kecil ump berdasarkan durasi pekerjaan
        $big_ump_count_6_bulan = 0;
        $small_ump_count_6_bulan = 0;
        $big_ump_count_more_6_bulan = 0;
        $small_ump_count_more_6_bulan = 0;

        // Inisialisasi array untuk menyimpan hasil
        $result_data = [];

        // Iterasi melalui hasil query
        foreach ($results as $row) {
            // Mendapatkan nilai u14
            $u14 = $row['u14'];
            // Mendapatkan nilai u16
            $u16 = $row['u16'];
            // Mendapatkan nilai u12
            $u12 = $row['u12'];
            // Mendapatkan nilai u7_1
            $u7_1 = $row['u7_1'];

            // Skip if u7_1 is not 1
            if ($u7_1 != 1) {
                continue;
            }

            // Mendapatkan nilai ump dari kode provinsi yang sesuai dengan u16
            $ump_query = $this->db->table('ump_20')
                ->select('ump')
                ->where('kode_provinsi', $u16)
                ->get();
            $ump_row = $ump_query->getRow();

            // Mengalikan nilai ump dengan 1.2
            $multiplied_ump = $ump_row ? $ump_row->ump * 1.2 : null;

            // Membandingkan nilai u14 dengan nilai ump dikali 1.2
            if ($multiplied_ump !== null) {
                if ($u14 < $multiplied_ump) {
                    if ($u12 == 1) {
                        $small_ump_count_6_bulan++;
                    } elseif ($u12 == 2) {
                        $small_ump_count_more_6_bulan++;
                    }
                    $comparison_result = 'Kecil UMP';
                } elseif ($u14 > $multiplied_ump) {
                    if ($u12 == 1) {
                        $big_ump_count_6_bulan++;
                    } elseif ($u12 == 2) {
                        $big_ump_count_more_6_bulan++;
                    }
                    $comparison_result = 'Besar UMP';
                } else {
                    $comparison_result = 'Sama dengan UMP';
                }
            } else {
                // UMP tidak ditemukan
                $comparison_result = 'UMP tidak tersedia';
            }

            // Menentukan status berdasarkan nilai u12
            $employment_duration = '';
            if ($u12 == 1) {
                $employment_duration = 'Kurang dari 6 bulan';
            } elseif ($u12 == 2) {
                $employment_duration = 'Lebih dari 6 bulan';
            }

            // Tambahkan data ke dalam array hasil
            $result_data[] = [
                'u14' => $u14,
                'u16' => $u16,
                'multiplied_ump' => $multiplied_ump, // Tambahkan nilai ump yang telah dikali 1.2
                'comparison_result' => $comparison_result,
                'employment_duration' => $employment_duration,
                'u7_1' => $u7_1
            ];
        }

        // Return hasil dan jumlah nilai besar dan kecil ump
        return [
            'result_data' => $result_data,
            'big_ump_count_6_bulan' => $big_ump_count_6_bulan,
            'small_ump_count_6_bulan' => $small_ump_count_6_bulan,
            'big_ump_count_more_6_bulan' => $big_ump_count_more_6_bulan,
            'small_ump_count_more_6_bulan' => $small_ump_count_more_6_bulan
        ];
    }

    // PENDAPATAN YG WIRASWATA
    public function wiraswasta()
    {
        $query = $this->getProgramStudiQuery();

        // Ambil data dari tabel 23_for_22
        $query = $query->select('u14, u16, u12, u7_1')->get();

        // Mengambil hasil query dalam bentuk array
        $data_rows = $query->getResultArray();

        // Menginisialisasi variabel untuk menyimpan jumlah nilai besar dan kecil ump berdasarkan durasi pekerjaan
        $count_large_ump_less_6_months = 0;
        $count_small_ump_less_6_months = 0;
        $count_large_ump_more_6_months = 0;
        $count_small_ump_more_6_months = 0;

        // Inisialisasi array untuk menyimpan hasil
        $processed_data = [];

        // Iterasi melalui hasil query
        foreach ($data_rows as $data_row) {
            // Mendapatkan nilai u14
            $value_u14 = $data_row['u14'];
            // Mendapatkan nilai u16
            $value_u16 = $data_row['u16'];
            // Mendapatkan nilai u12
            $value_u12 = $data_row['u12'];
            // Mendapatkan nilai u7_1
            $value_u7_1 = $data_row['u7_1'];

            // Skip if u7_1 is not 4
            if ($value_u7_1 != 2) {
                continue;
            }

            // Mendapatkan nilai ump dari kode provinsi yang sesuai dengan u16
            $ump_query = $this->db->table('ump_20')
                ->select('ump')
                ->where('kode_provinsi', $value_u16)
                ->get();
            $ump_row = $ump_query->getRow();

            // Mengalikan nilai ump dengan 1.2
            $multiplied_ump_value = $ump_row ? $ump_row->ump * 1.2 : null;

            // Membandingkan nilai u14 dengan nilai ump dikali 1.2
            if ($multiplied_ump_value !== null) {
                if ($value_u14 < $multiplied_ump_value) {
                    if ($value_u12 == 1) {
                        $count_small_ump_less_6_months++;
                    } elseif ($value_u12 == 2) {
                        $count_small_ump_more_6_months++;
                    }
                    $comparison_result = 'Kecil UMP';
                } elseif ($value_u14 > $multiplied_ump_value) {
                    if ($value_u12 == 1) {
                        $count_large_ump_less_6_months++;
                    } elseif ($value_u12 == 2) {
                        $count_large_ump_more_6_months++;
                    }
                    $comparison_result = 'Besar UMP';
                } else {
                    $comparison_result = 'Sama dengan UMP';
                }
            } else {
                // UMP tidak ditemukan
                $comparison_result = 'UMP tidak tersedia';
            }

            // Menentukan status berdasarkan nilai u12
            $employment_duration = '';
            if ($value_u12 == 1) {
                $employment_duration = 'Kurang dari 6 bulan';
            } elseif ($value_u12 == 2) {
                $employment_duration = 'Lebih dari 6 bulan';
            }

            // Tambahkan data ke dalam array hasil
            $processed_data[] = [
                'u14' => $value_u14,
                'u16' => $value_u16,
                'multiplied_ump_value' => $multiplied_ump_value, // Tambahkan nilai ump yang telah dikali 1.2
                'comparison_result' => $comparison_result,
                'employment_duration' => $employment_duration,
                'u7_1' => $value_u7_1
            ];
        }

        // Return hasil dan jumlah nilai besar dan kecil ump
        return [
            'processed_data' => $processed_data,
            'count_large_ump_less_6_months' => $count_large_ump_less_6_months,
            'count_small_ump_less_6_months' => $count_small_ump_less_6_months,
            'count_large_ump_more_6_months' => $count_large_ump_more_6_months,
            'count_small_ump_more_6_months' => $count_small_ump_more_6_months
        ];
    }

    // END PENDAPATAN YG WIRASWASTA

    public function Status()
    {
        $query = $this->getProgramStudiQuery();

        // Menggunakan fungsi agregasi SUM() untuk menjumlahkan data yang memiliki nilai yang sama di kolom 'u7_1'
        $query = $query->select('u7_1, COUNT(u7_1) as total')
            ->groupBy('u7_1')
            ->get();

        // Mengonversi hasil query menjadi array
        $results_status = $query->getResultArray();

        // Menginisialisasi array untuk menyimpan hasil penjumlahan
        $sums = [];

        // Iterasi melalui hasil query dan menyimpan hasil penjumlahan ke dalam array
        foreach ($results_status as $result) {
            $sums[$result['u7_1']] = $result['total'];
        }

        return $sums;
    }

    public function tesquery()
    {
        // Mengambil semua nilai kolom 'u15' di mana nilai kolom 'program_studi' adalah 'DIV - Teknik Telekomunikasi'
        return $this->select('u15')->where('program_studi', 'DIV - Teknik Telekomunikasi')->findAll();
    }
}
