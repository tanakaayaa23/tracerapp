<?php

namespace App\Models\Teknik_Mesin;

use CodeIgniter\Model;

class TM_D3TAE_22 extends Model
{
    protected $table = '23_for_22';

    // Metode pembantu untuk filter program_studi
    protected function getProgramStudiQuery()
    {
        return $this->where('program_studi', 'DIII - Teknik Aeronautika');
    }

    public function waktuTunggu()
    {
        $query = $this->getProgramStudiQuery();

        // Menghitung total nilai untuk kolom p15 dan p16
        $totalsQuery = $query->select('SUM(p15) AS total_p15, SUM(p16) AS total_p16')->get();
        $totals = $totalsQuery->getRow();

        // Menghitung jumlah (count) nilai untuk kolom p15 dan p16
        $countsQuery = $this->getProgramStudiQuery()->select('COUNT(p15) AS count_p15, COUNT(p16) AS count_p16')->get();
        $counts = $countsQuery->getRow();

        // Menghindari pembagian dengan nol
        $countSum = $counts->count_p15 + $counts->count_p16;
        if ($countSum == 0) {
            $average = null; // Atau Anda bisa mengembalikan nilai default seperti 0
        } else {
            // Menghitung rata-rata
            $average = round(($totals->total_p15 + $totals->total_p16) / $countSum);
        }

        // Menghitung persentase
        $total = $counts->count_p15 + $counts->count_p16;
        if ($total == 0) {
            $percentage_p15 = 0;
            $percentage_p16 = 0;
        } else {
            $percentage_p15 = ($counts->count_p15 / $total) * 100;
            $percentage_p16 = ($counts->count_p16 / $total) * 100;
        }

        return [
            'average' => $average,
            'percentage_p15' => $percentage_p15,
            'percentage_p16' => $percentage_p16,
        ];
    }

    // Keselarasan Vertikal
    public function KeselarasanVertikal()
    {
        $query = $this->getProgramStudiQuery();

        // Menggunakan fungsi agregasi SUM() untuk menjumlahkan data yang memiliki nilai yang sama di kolom 'p27' dengan filter program_studi
        $query = $query->select('p27, COUNT(p27) as total')
            ->groupBy('p27')
            ->get();

        // Mengonversi hasil query menjadi array
        $results = $query->getResultArray();

        // Menginisialisasi array untuk menyimpan hasil penjumlahan
        $sums = [];

        // Iterasi melalui hasil query dan menyimpan hasil penjumlahan ke dalam array
        foreach ($results as $result) {
            $sums[$result['p27']] = $result['total'];
        }

        return $sums;
    }

    // Keselarasan Horizontal
    public function KeselarasanHorizontal()
    {
        $query = $this->getProgramStudiQuery();

        // Menggunakan fungsi agregasi SUM() untuk menjumlahkan data yang memiliki nilai yang sama di kolom 'p26' dengan filter program_studi
        $query = $query->select('p26, COUNT(p26) as total')
            ->groupBy('p26')
            ->get();

        // Mengonversi hasil query menjadi array
        $results = $query->getResultArray();

        // Menginisialisasi array untuk menyimpan hasil penjumlahan
        $sums2 = [];

        // Iterasi melalui hasil query dan menyimpan hasil penjumlahan ke dalam array
        foreach ($results as $result) {
            $sums2[$result['p26']] = $result['total'];
        }

        return $sums2;
    }

    public function TingkatTempatBekerja()
    {
        $query = $this->getProgramStudiQuery();

        // Menghitung total data
        $totalQuery = $query->select('COUNT(p25) as total')->get();
        $totalResult = $totalQuery->getRowArray();
        $total = $totalResult['total'];

        // Menggunakan fungsi agregasi COUNT() untuk menghitung jumlah data untuk setiap nilai di kolom 'p25' dengan filter program_studi
        $query = $this->getProgramStudiQuery()->select('p25, COUNT(p25) as count')
            ->groupBy('p25')
            ->get();

        // Mengonversi hasil query menjadi array
        $results = $query->getResultArray();

        // Menginisialisasi array untuk menyimpan hasil persentase
        $percentages = [];

        // Iterasi melalui hasil query dan menghitung persentase untuk setiap nilai
        foreach ($results as $result) {
            $percentage = ($result['count'] / $total) * 100;
            $percentages[$result['p25']] = $percentage;
        }

        return $percentages;
    }

    public function bekerja()
    {
        $query = $this->getProgramStudiQuery();

        // Ambil data dari tabel 23_for_22 untuk 'DIII - Teknik Aeronautika' saja
        $query = $query->select('p18, p19, p14, p9')->get();

        // Mengambil hasil query dalam bentuk array
        $results = $query->getResultArray();

        // Menginisialisasi variabel untuk menyimpan jumlah nilai besar dan kecil ump berdasarkan durasi pekerjaan
        $big_ump_count_6_bulan = 0;
        $small_ump_count_6_bulan = 0;
        $big_ump_count_more_6_bulan = 0;
        $small_ump_count_more_6_bulan = 0;

        // Inisialisasi array untuk menyimpan hasil
        $result_data = [];

        // Iterasi melalui hasil query
        foreach ($results as $row) {
            // Mendapatkan nilai p18
            $p18 = $row['p18'];
            // Mendapatkan nilai p19
            $p19 = $row['p19'];
            // Mendapatkan nilai p14
            $p14 = $row['p14'];
            // Mendapatkan nilai p9
            $p9 = $row['p9'];

            // Skip if p9 is not 1
            if ($p9 != 1) {
                continue;
            }

            // Mendapatkan nilai ump dari kode provinsi yang sesuai dengan p19
            $ump_query = $this->db->table('provinsi')
                ->select('ump')
                ->where('kode_provinsi', $p19)
                ->get();
            $ump_row = $ump_query->getRow();

            // Mengalikan nilai ump dengan 1.2
            $multiplied_ump = $ump_row ? $ump_row->ump * 1.2 : null;

            // Membandingkan nilai p18 dengan nilai ump dikali 1.2
            if ($multiplied_ump !== null) {
                if ($p18 < $multiplied_ump) {
                    if ($p14 == 1) {
                        $small_ump_count_6_bulan++;
                    } elseif ($p14 == 2) {
                        $small_ump_count_more_6_bulan++;
                    }
                    $comparison_result = 'Kecil UMP';
                } elseif ($p18 > $multiplied_ump) {
                    if ($p14 == 1) {
                        $big_ump_count_6_bulan++;
                    } elseif ($p14 == 2) {
                        $big_ump_count_more_6_bulan++;
                    }
                    $comparison_result = 'Besar UMP';
                } else {
                    $comparison_result = 'Sama dengan UMP';
                }
            } else {
                // UMP tidak ditemukan
                $comparison_result = 'UMP tidak tersedia';
            }

            // Menentukan status berdasarkan nilai p14
            $employment_duration = '';
            if ($p14 == 1) {
                $employment_duration = 'Kurang dari 6 bulan';
            } elseif ($p14 == 2) {
                $employment_duration = 'Lebih dari 6 bulan';
            }

            // Tambahkan data ke dalam array hasil
            $result_data[] = [
                'p18' => $p18,
                'p19' => $p19,
                'multiplied_ump' => $multiplied_ump, // Tambahkan nilai ump yang telah dikali 1.2
                'comparison_result' => $comparison_result,
                'employment_duration' => $employment_duration,
                'p9' => $p9
            ];
        }

        // Return hasil dan jumlah nilai besar dan kecil ump
        return [
            'result_data' => $result_data,
            'big_ump_count_6_bulan' => $big_ump_count_6_bulan,
            'small_ump_count_6_bulan' => $small_ump_count_6_bulan,
            'big_ump_count_more_6_bulan' => $big_ump_count_more_6_bulan,
            'small_ump_count_more_6_bulan' => $small_ump_count_more_6_bulan
        ];
    }

    // PENDAPATAN YG WIRASWATA
    public function wiraswasta()
    {
        $query = $this->getProgramStudiQuery();

        // Ambil data dari tabel 23_for_22
        $query = $query->select('p18, p19, p14, p9')->get();

        // Mengambil hasil query dalam bentuk array
        $data_rows = $query->getResultArray();

        // Menginisialisasi variabel untuk menyimpan jumlah nilai besar dan kecil ump berdasarkan durasi pekerjaan
        $count_large_ump_less_6_months = 0;
        $count_small_ump_less_6_months = 0;
        $count_large_ump_more_6_months = 0;
        $count_small_ump_more_6_months = 0;

        // Inisialisasi array untuk menyimpan hasil
        $processed_data = [];

        // Iterasi melalui hasil query
        foreach ($data_rows as $data_row) {
            // Mendapatkan nilai p18
            $value_p18 = $data_row['p18'];
            // Mendapatkan nilai p19
            $value_p19 = $data_row['p19'];
            // Mendapatkan nilai p14
            $value_p14 = $data_row['p14'];
            // Mendapatkan nilai p9
            $value_p9 = $data_row['p9'];

            // Skip if p9 is not 4
            if ($value_p9 != 3) {
                continue;
            }

            // Mendapatkan nilai ump dari kode provinsi yang sesuai dengan p19
            $ump_query = $this->db->table('provinsi')
                ->select('ump')
                ->where('kode_provinsi', $value_p19)
                ->get();
            $ump_row = $ump_query->getRow();

            // Mengalikan nilai ump dengan 1.2
            $multiplied_ump_value = $ump_row ? $ump_row->ump * 1.2 : null;

            // Membandingkan nilai p18 dengan nilai ump dikali 1.2
            if ($multiplied_ump_value !== null) {
                if ($value_p18 < $multiplied_ump_value) {
                    if ($value_p14 == 1) {
                        $count_small_ump_less_6_months++;
                    } elseif ($value_p14 == 2) {
                        $count_small_ump_more_6_months++;
                    }
                    $comparison_result = 'Kecil UMP';
                } elseif ($value_p18 > $multiplied_ump_value) {
                    if ($value_p14 == 1) {
                        $count_large_ump_less_6_months++;
                    } elseif ($value_p14 == 2) {
                        $count_large_ump_more_6_months++;
                    }
                    $comparison_result = 'Besar UMP';
                } else {
                    $comparison_result = 'Sama dengan UMP';
                }
            } else {
                // UMP tidak ditemukan
                $comparison_result = 'UMP tidak tersedia';
            }

            // Menentukan status berdasarkan nilai p14
            $employment_duration = '';
            if ($value_p14 == 1) {
                $employment_duration = 'Kurang dari 6 bulan';
            } elseif ($value_p14 == 2) {
                $employment_duration = 'Lebih dari 6 bulan';
            }

            // Tambahkan data ke dalam array hasil
            $processed_data[] = [
                'p18' => $value_p18,
                'p19' => $value_p19,
                'multiplied_ump_value' => $multiplied_ump_value, // Tambahkan nilai ump yang telah dikali 1.2
                'comparison_result' => $comparison_result,
                'employment_duration' => $employment_duration,
                'p9' => $value_p9
            ];
        }

        // Return hasil dan jumlah nilai besar dan kecil ump
        return [
            'processed_data' => $processed_data,
            'count_large_ump_less_6_months' => $count_large_ump_less_6_months,
            'count_small_ump_less_6_months' => $count_small_ump_less_6_months,
            'count_large_ump_more_6_months' => $count_large_ump_more_6_months,
            'count_small_ump_more_6_months' => $count_small_ump_more_6_months
        ];
    }

    // END PENDAPATAN YG WIRASWASTA

    public function Status()
    {
        $query = $this->getProgramStudiQuery();

        // Menggunakan fungsi agregasi SUM() untuk menjumlahkan data yang memiliki nilai yang sama di kolom 'p9'
        $query = $query->select('p9, COUNT(p9) as total')
            ->groupBy('p9')
            ->get();

        // Mengonversi hasil query menjadi array
        $results_status = $query->getResultArray();

        // Menginisialisasi array untuk menyimpan hasil penjumlahan
        $sums = [];

        // Iterasi melalui hasil query dan menyimpan hasil penjumlahan ke dalam array
        foreach ($results_status as $result) {
            $sums[$result['p9']] = $result['total'];
        }

        return $sums;
    }

    public function tesquery()
    {
        // Mengambil semua nilai kolom 'p16' di mana nilai kolom 'program_studi' adalah 'DIII - Teknik Aeronautika'
        return $this->select('p16')->where('program_studi', 'DIII - Teknik Aeronautika')->findAll();
    }
}
